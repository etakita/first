package ru.vtb.streaming.player;

import java.util.Locale;
import java.util.logging.Formatter;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;

public final class App {

    private App() {
    }

    public static void main(String[] args) {
        Locale.setDefault(Locale.ROOT);
        configureLogging();
        int code;
        if (args.length == 0 || args[0].equals("help") || args[0].equals("-h") || args[0].equals("--help")) {
            code = args.length == 0 ? 1 : 0;
        } else if (args[0].equals("transmit")) {
            code = new ru.vtb.streaming.player.transmit.TransmitCommand()
                    .run(java.util.Arrays.copyOfRange(args, 1, args.length));
        } else {
            System.err.println("Unknown command: " + args[0]);
            code = 1;
        }
        System.exit(code);
    }

    private static void configureLogging() {
        Logger root = Logger.getLogger("");
        root.setLevel(Level.INFO);
        for (Handler h : root.getHandlers()) {
            h.setLevel(Level.INFO);
            try {
                h.setEncoding("UTF-8");
            } catch (java.io.UnsupportedEncodingException ignored) {
            }
            h.setFormatter(new Formatter() {
                @Override
                public String format(LogRecord r) {
                    return String.format("[%1$tH:%1$tM:%1$tS] %2$-7s %3$s%n",
                            r.getMillis(), r.getLevel().getName(), r.getMessage());
                }
            });
        }
    }
}
