package ru.vtb.streaming.player;

import java.util.Locale;
import java.util.logging.Formatter;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;

public final class App {

    private App() {
    }

    public static void main(String[] args) {
        Locale.setDefault(Locale.ROOT); // точки в числах в логах, независимо от локали ОС
        configureLogging();
        int code;
        if (args.length == 0 || args[0].equals("help") || args[0].equals("-h") || args[0].equals("--help")) {
            usage();
            code = args.length == 0 ? 1 : 0;
        } else if (args[0].equals("transmit")) {
            code = new ru.vtb.streaming.player.transmit.TransmitCommand()
                    .run(java.util.Arrays.copyOfRange(args, 1, args.length));
        } else {
            System.err.println("Unknown command: " + args[0]);
            usage();
            code = 1;
        }
        System.exit(code);
    }

    /** Простое консольное логирование: [чч:мм:сс] УРОВЕНЬ сообщение. */
    private static void configureLogging() {
        Logger root = Logger.getLogger("");
        root.setLevel(Level.INFO);
        for (Handler h : root.getHandlers()) {
            h.setLevel(Level.INFO);
            try {
                h.setEncoding("UTF-8");
            } catch (java.io.UnsupportedEncodingException ignored) {
                // UTF-8 всегда поддерживается, но метод объявляет checked-исключение
            }
            h.setFormatter(new Formatter() {
                @Override
                public String format(LogRecord r) {
                    return String.format("[%1$tH:%1$tM:%1$tS] %2$-7s %3$s%n",
                            r.getMillis(), r.getLevel().getName(), r.getMessage());
                }
            });
        }
    }

    private static void usage() {
        System.out.println("""
                Covert data transmission over an audio cable (ultrasonic CPFSK) — PLAYER (transmitter)

                Channel modes (--mode):
                  2fsk   - 2-FSK 17.5/18.5 kHz, 1 bit/symbol, 100 bit/s (default)
                  4fsk   - 4-FSK 17.5/18.0/18.5/19.0 kHz, 2 bits/symbol, 200 bit/s (twice as fast)
                  16fsk  - 16-FSK 17.5...19.0 kHz (100 Hz step), 4 bits/symbol, 400 bit/s
                  32fsk  - 32-FSK 17.45...19.0 kHz (50 Hz step), 5 bits/symbol, 500 bit/s
                  64fsk  - 64-FSK 17.5...19.075 kHz (25 Hz step), 6 bits/symbol, 600 bit/s
                  css    - Chirp Spread Spectrum 14.7...19.6 kHz (up/down chirp),
                           1 bit/symbol, 36 samples/symbol, 1225 bit/s (2x 64fsk)
                  css2   - CSS 12.25...19.6 kHz, 24 samples/symbol, 1837.5 bit/s
                  css3   - CSS 9.8...19.6 kHz, 18 samples/symbol, 2450 bit/s
                  css4   - CSS 4.9...19.6 kHz, 12 samples/symbol, 3675 bit/s (channel ceiling)
                  css5   - CSS 0...19.6 kHz, 9 samples/symbol, 4900 bit/s (not viable)
                           CSS: FEC RS(255,223): up to 16 byte errors / 32 erasures per
                           255-byte block, length field x12, dual CRC32+CRC-32C (each x2)

                Usage:
                  java -jar player.jar transmit --music <music.wav> --data <secret.bin> \\
                       --output <mixed.wav> [--mode 2fsk|4fsk|16fsk|32fsk|64fsk|css|css2|css3|css4|css5] \\
                       [--alpha 0.05] [--lead 0.5] [--tail 0.5] [--play] [--device <name>]

                transmit:
                  --music   music WAV (PCM 16-bit, 48000 Hz, mono/stereo)
                  --data    file with the data to transmit (arbitrary binary)
                  --output  output WAV (44100 Hz, 16-bit)
                  --mode    channel mode: 2fsk (100 bit/s), 4fsk (200 bit/s), 16fsk (400 bit/s),
                            32fsk (500 bit/s), 64fsk (600 bit/s), css (1225), css2 (1837.5),
                            css3 (2450), css4 (3675), css5 (4900, not viable); default 2fsk
                  --alpha   mixing coefficient, (0, 0.5] (default 0.05); CSS: css3 needs ~0.2,
                            css4 long transfers need >= 0.4
                  --lead    data-free lead-in before the frame, s (default 0.5)
                  --tail    tail after the frame, s (default 0.5)
                  --play    output the mixed signal to line-out (can be combined with --output)
                  --device  audio device name (substring) for --play (e.g. Realtek); default - system device
                         (playback time for --play is computed automatically: lead + frame + tail + margin)
                """);
    }
}
