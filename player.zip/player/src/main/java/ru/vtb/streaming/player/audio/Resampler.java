package ru.vtb.streaming.player.audio;

/**
 * Линейный ресемплер (произвольная частота → целевая).
 *
 * Для этой задачи линейной интерполяции достаточно: скрытый сигнал НЕ ресемплируется
 * (он генерируется сразу на 44100 Гц), а музыка пропускается через интерполяцию только
 * для согласования частоты; в ультразвуковой области это даёт лишь плавную
 * амплитудную коррекцию, слышимых искажений нет.
 */
public final class Resampler {

    private Resampler() {
    }

    /**
     * Пересемплирует все каналы в целевую частоту.
     *
     * @return тот же объект, если частота уже совпадает
     */
    public static WavData resample(WavData in, int targetRate) {
        if (in.sampleRate == targetRate) {
            return in;
        }
        double ratio = in.sampleRate / (double) targetRate; // src -> dst
        int frames = (int) Math.round(in.frameCount() / ratio);
        float[][] out = new float[in.channelCount()][frames];
        for (int c = 0; c < in.channelCount(); c++) {
            float[] s = in.channels[c];
            float[] d = out[c];
            for (int i = 0; i < frames; i++) {
                double srcPos = i * ratio;
                int i0 = (int) srcPos;
                int i1 = Math.min(i0 + 1, s.length - 1);
                double frac = srcPos - i0;
                d[i] = (float) (s[i0] * (1.0 - frac) + s[i1] * frac);
            }
        }
        return new WavData(targetRate, out);
    }
}
