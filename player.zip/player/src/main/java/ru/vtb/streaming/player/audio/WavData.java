package ru.vtb.streaming.player.audio;

/**
 * Аудио в памяти: PCM 16-bit, переведённый в float [-1..1], по массиву на канал.
 */
public final class WavData {

    /** Частота дискретизации, Гц. */
    public final int sampleRate;
    /** Каналы: channels[канал][сэмпл]. */
    public final float[][] channels;

    public WavData(int sampleRate, float[][] channels) {
        this.sampleRate = sampleRate;
        this.channels = channels;
    }

    public int channelCount() {
        return channels.length;
    }

    public int frameCount() {
        return channels.length == 0 ? 0 : channels[0].length;
    }

    /**
     * Смешивает каналы в моно (среднее арифметическое).
     */
    public float[] toMono() {
        int n = frameCount();
        int ch = channelCount();
        if (ch == 1) {
            return channels[0].clone();
        }
        float[] m = new float[n];
        for (int c = 0; c < ch; c++) {
            float[] d = channels[c];
            for (int i = 0; i < n; i++) {
                m[i] += d[i];
            }
        }
        for (int i = 0; i < n; i++) {
            m[i] /= ch;
        }
        return m;
    }
}
