package ru.vtb.streaming.player.audio;

public final class WavData {

    public final int sampleRate;
    public final float[][] channels;

    public WavData(int sampleRate, float[][] channels) {
        this.sampleRate = sampleRate;
        this.channels = channels;
    }

    public int channelCount() {
        return channels.length;
    }

    public int frameCount() {
        return channels.length == 0 ? 0 : channels[0].length;
    }

    public float[] toMono() {
        int n = frameCount();
        int ch = channelCount();
        if (ch == 1) {
            return channels[0].clone();
        }
        float[] m = new float[n];
        for (int c = 0; c < ch; c++) {
            float[] d = channels[c];
            for (int i = 0; i < n; i++) {
                m[i] += d[i];
            }
        }
        for (int i = 0; i < n; i++) {
            m[i] /= ch;
        }
        return m;
    }
}
