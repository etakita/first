package ru.vtb.streaming.player.audio;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Минимальный кодек WAV (PCM, 16-bit, mono/stereo).
 * Чтение: находит чанки fmt / data, все остальные (LIST, INFO, ...) пропускает.
 * Запись: классический RIFF/WAVE с чанками fmt + data.
 */
public final class WavFile {

    private WavFile() {
    }

    /** Чтение WAV в {@link WavData}. */
    public static WavData read(Path path) throws IOException {
        byte[] raw = Files.readAllBytes(path);
        if (raw.length < 44) {
            throw new IOException("File too small for WAV: " + path);
        }
        ByteBuffer bb = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN);
        if (!tag(bb, 4).equals("RIFF")) {
            throw new IOException("Not a WAV file (no RIFF): " + path);
        }
        bb.getInt(); // размер RIFF-блока (не нужен)
        if (!tag(bb, 4).equals("WAVE")) {
            throw new IOException("Not a WAV file (no WAVE): " + path);
        }

        int fmt = -1, bits = -1, sr = -1, ch = -1;
        int dataOffset = -1, dataLen = -1;
        while (bb.remaining() >= 8) {
            String id = tag(bb, 4);
            int size = bb.getInt();
            int bodyStart = bb.position(); // тело чанка начинается здесь

            switch (id) {
                case "fmt " -> {
                    if (size < 16) {
                        throw new IOException("Invalid fmt chunk (size " + size + "): " + path);
                    }
                    int p = bodyStart;
                    fmt = bb.getShort(p) & 0xFFFF;
                    p += 2;
                    ch = bb.getShort(p) & 0xFFFF;
                    p += 2;
                    sr = bb.getInt(p);
                    p += 4;
                    p += 4; // byte rate
                    p += 2; // block align
                    bits = bb.getShort(p) & 0xFFFF;
                }
                case "data" -> {
                    dataOffset = bodyStart;
                    dataLen = size;
                }
                default -> {
                    // неизвестный чанк (LIST/INFO и т.п.) — пропускаем
                }
            }

            // Абсолютный прыжок в конец чанка (выравнивание по чётному байту).
            // Важно: именно абсолютный, а не относительный skip — иначе чанки,
            // чьё тело уже прочитано (fmt), пропускались бы дважды.
            int end = bodyStart + size + (size & 1);
            if (end > raw.length) {
                break; // файл обрезан
            }
            bb.position(end);
        }

        if (sr <= 0 || ch <= 0 || dataOffset < 0) {
            throw new IOException("No data chunk in WAV: " + path);
        }
        if (fmt != 1) {
            throw new IOException("Expected PCM (format=1), got format=" + fmt + ": " + path);
        }
        if (bits != 16) {
            throw new IOException("Expected 16-bit PCM, got " + bits + "-bit: " + path);
        }
        int samples = Math.min(dataLen, raw.length - dataOffset) / 2;
        int frames = samples / ch;
        float[][] channels = new float[ch][frames];
        int s = 0;
        for (int f = 0; f < frames; f++) {
            for (int c = 0; c < ch; c++) {
                channels[c][f] = (short) ((raw[dataOffset + 2 * s] & 0xFF) | (raw[dataOffset + 2 * s + 1] << 8))
                        / 32768f;
                s++;
            }
        }
        return new WavData(sr, channels);
    }

    /** Запись WAV: PCM 16-bit, little-endian, mono/stereo. */
    public static void write(Path path, int sampleRate, float[][] channels) throws IOException {
        int ch = channels.length;
        int frames = channels[0].length;
        int dataBytes = frames * ch * 2;
        byte[] hdr = new byte[44];
        ByteBuffer b = ByteBuffer.wrap(hdr).order(ByteOrder.LITTLE_ENDIAN);
        b.put("RIFF".getBytes(StandardCharsets.US_ASCII));
        b.putInt(36 + dataBytes);
        b.put("WAVE".getBytes(StandardCharsets.US_ASCII));
        b.put("fmt ".getBytes(StandardCharsets.US_ASCII));
        b.putInt(16);
        b.putShort((short) 1);            // PCM
        b.putShort((short) ch);
        b.putInt(sampleRate);
        b.putInt(sampleRate * ch * 2);    // byte rate
        b.putShort((short) (ch * 2));     // block align
        b.putShort((short) 16);           // bits
        b.put("data".getBytes(StandardCharsets.US_ASCII));
        b.putInt(dataBytes);

        byte[] payload = new byte[dataBytes];
        for (int f = 0; f < frames; f++) {
            for (int c = 0; c < ch; c++) {
                float v = channels[c][f];
                if (v > 1.0f) {
                    v = 1.0f;
                } else if (v < -1.0f) {
                    v = -1.0f;
                }
                short s = (short) Math.round(v * 32767.0f);
                int o = f * ch * 2 + c * 2;
                payload[o] = (byte) (s & 0xFF);
                payload[o + 1] = (byte) ((s >>> 8) & 0xFF);
            }
        }
        try (OutputStream os = Files.newOutputStream(path)) {
            os.write(hdr);
            os.write(payload);
        }
    }

    /** Чтение 4-байтного тега чанка. */
    private static String tag(ByteBuffer bb, int n) {
        byte[] t = new byte[n];
        bb.get(t);
        return new String(t, StandardCharsets.US_ASCII);
    }
}
