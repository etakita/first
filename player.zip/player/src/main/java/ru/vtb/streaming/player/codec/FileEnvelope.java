package ru.vtb.streaming.player.codec;

import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class FileEnvelope {

    public static final byte[] MAGIC = {'U', 'F', 'S', '1'};
    public static final byte[] MAGIC2 = {'U', 'F', 'S', '2'};
    public static final byte[] MAGIC3 = {'U', 'F', 'S', '3'};
    public static final byte[] MAGIC4 = {'U', 'F', 'S', '4'};
    public static final int MAGIC_LEN = MAGIC.length;
    public static final int NAME_MAX = 512;

    private FileEnvelope() {
    }

    public record Parsed(String name, byte[] data, int dataOffset, int index, int total,
                         String[] seriesNames, long[] seriesSizes, boolean preamble) {
        public boolean hasName() {
            return name != null;
        }

        public boolean hasProgress() {
            return index >= 1 && total >= 1;
        }

        public boolean hasManifest() {
            return seriesNames != null;
        }

        public boolean isPreamble() {
            return preamble;
        }

        public int overhead() {
            return dataOffset;
        }
    }

    public static byte[] wrap(String name, byte[] data) {
        return wrap(name, data, 0, 0);
    }

    public static byte[] wrap(String name, byte[] data, int index, int total) {
        return wrap(name, data, index, total, null, null);
    }

    public static byte[] wrap(String name, byte[] data, int index, int total,
                              String[] names, long[] sizes) {
        validateName(name);
        byte[] nameBytes = name.getBytes(StandardCharsets.UTF_8);
        boolean series = (index >= 1) && (total >= 1);
        boolean manifest = series && names != null && sizes != null && names.length == sizes.length;
        if (series && names != null && sizes != null && names.length != sizes.length) {
            throw new IllegalArgumentException("manifest: names and sizes must have equal length");
        }
        if (total > 0xFFFF) {
            throw new IllegalArgumentException("series too long: " + total + " files");
        }
        int manifestLen = 0;
        byte[][] manifestNames = null;
        if (manifest) {
            manifestNames = new byte[names.length][];
            for (int i = 0; i < names.length; i++) {
                validateName(names[i]);
                manifestNames[i] = names[i].getBytes(StandardCharsets.UTF_8);
                if (manifestNames[i].length > NAME_MAX) {
                    throw new IllegalArgumentException("manifest name too long: " + names[i]);
                }
                manifestLen += 2 + manifestNames[i].length + 4;
            }
        }
        int extra = series ? 4 : 0;
        byte[] out = new byte[MAGIC_LEN + 2 + nameBytes.length + extra + manifestLen + data.length];
        System.arraycopy(series ? (manifest ? MAGIC3 : MAGIC2) : MAGIC, 0, out, 0, MAGIC_LEN);
        out[MAGIC_LEN] = (byte) (nameBytes.length >>> 8);
        out[MAGIC_LEN + 1] = (byte) nameBytes.length;
        System.arraycopy(nameBytes, 0, out, MAGIC_LEN + 2, nameBytes.length);
        int off = MAGIC_LEN + 2 + nameBytes.length;
        if (series) {
            out[off] = (byte) (index >>> 8);
            out[off + 1] = (byte) index;
            out[off + 2] = (byte) (total >>> 8);
            out[off + 3] = (byte) total;
            off += 4;
        }
        if (manifest) {
            for (int i = 0; i < manifestNames.length; i++) {
                byte[] n = manifestNames[i];
                out[off] = (byte) (n.length >>> 8);
                out[off + 1] = (byte) n.length;
                System.arraycopy(n, 0, out, off + 2, n.length);
                off += 2 + n.length;
                long s = sizes[i] & 0xFFFFFFFFL;
                out[off] = (byte) (s >>> 24);
                out[off + 1] = (byte) (s >>> 16);
                out[off + 2] = (byte) (s >>> 8);
                out[off + 3] = (byte) s;
                off += 4;
            }
        }
        System.arraycopy(data, 0, out, off, data.length);
        return out;
    }

    public static byte[] wrapPreamble(String[] names, long[] sizes) {
        if (names == null || sizes == null || names.length != sizes.length) {
            throw new IllegalArgumentException("preamble: names and sizes must have equal length");
        }
        int total = names.length;
        if (total < 1) {
            throw new IllegalArgumentException("preamble: empty series");
        }
        if (total > 0xFFFF) {
            throw new IllegalArgumentException("series too long: " + total + " files");
        }
        int manifestLen = 0;
        byte[][] manifestNames = new byte[total][];
        for (int i = 0; i < total; i++) {
            validateName(names[i]);
            manifestNames[i] = names[i].getBytes(StandardCharsets.UTF_8);
            if (manifestNames[i].length > NAME_MAX) {
                throw new IllegalArgumentException("manifest name too long: " + names[i]);
            }
            manifestLen += 2 + manifestNames[i].length + 4;
        }
        byte[] out = new byte[MAGIC_LEN + 2 + manifestLen];
        System.arraycopy(MAGIC4, 0, out, 0, MAGIC_LEN);
        out[MAGIC_LEN] = (byte) (total >>> 8);
        out[MAGIC_LEN + 1] = (byte) total;
        int off = MAGIC_LEN + 2;
        for (int i = 0; i < total; i++) {
            byte[] n = manifestNames[i];
            out[off] = (byte) (n.length >>> 8);
            out[off + 1] = (byte) n.length;
            System.arraycopy(n, 0, out, off + 2, n.length);
            off += 2 + n.length;
            long s = sizes[i] & 0xFFFFFFFFL;
            out[off] = (byte) (s >>> 24);
            out[off + 1] = (byte) (s >>> 16);
            out[off + 2] = (byte) (s >>> 8);
            out[off + 3] = (byte) s;
            off += 4;
        }
        return out;
    }

    public static Parsed parse(byte[] payload) {
        if (payload.length < MAGIC_LEN + 2) {
            return raw(payload);
        }
        if (matches(payload, MAGIC4)) {
            return parsePreamble(payload);
        }
        boolean v3 = matches(payload, MAGIC3);
        boolean v2 = matches(payload, MAGIC2);
        boolean v1 = matches(payload, MAGIC);
        if (!v1 && !v2 && !v3) {
            return raw(payload);
        }
        int n = ((payload[MAGIC_LEN] & 0xFF) << 8) | (payload[MAGIC_LEN + 1] & 0xFF);
        if (n < 1 || n > NAME_MAX || MAGIC_LEN + 2 + n > payload.length) {
            return raw(payload);
        }
        String name;
        try {
            name = new String(payload, MAGIC_LEN + 2, n, StandardCharsets.UTF_8);
            validateName(name);
        } catch (RuntimeException e) {
            return raw(payload);
        }
        int off = MAGIC_LEN + 2 + n;
        int index = 0;
        int total = 0;
        String[] seriesNames = null;
        long[] seriesSizes = null;
        if (v2 || v3) {
            if (off + 4 > payload.length) {
                return raw(payload);
            }
            index = ((payload[off] & 0xFF) << 8) | (payload[off + 1] & 0xFF);
            total = ((payload[off + 2] & 0xFF) << 8) | (payload[off + 3] & 0xFF);
            off += 4;
            if (index < 1 || total < 1) {
                index = 0;
                total = 0;
            }
        }
        if (v3) {

            seriesNames = new String[total];
            seriesSizes = new long[total];
            try {
                for (int i = 0; i < total; i++) {
                    if (off + 2 > payload.length) {
                        throw new IllegalStateException("manifest truncated");
                    }
                    int ln = ((payload[off] & 0xFF) << 8) | (payload[off + 1] & 0xFF);
                    if (ln < 1 || ln > NAME_MAX || off + 2 + ln + 4 > payload.length) {
                        throw new IllegalStateException("manifest name invalid");
                    }
                    String mn = new String(payload, off + 2, ln, StandardCharsets.UTF_8);
                    validateName(mn);
                    seriesNames[i] = mn;
                    long s = ((payload[off + 2 + ln] & 0xFFL) << 24)
                            | ((payload[off + 3 + ln] & 0xFFL) << 16)
                            | ((payload[off + 4 + ln] & 0xFFL) << 8)
                            | (payload[off + 5 + ln] & 0xFFL);
                    seriesSizes[i] = s;
                    off += 2 + ln + 4;
                }
            } catch (RuntimeException e) {
                return raw(payload);
            }
        }
        byte[] data = new byte[payload.length - off];
        System.arraycopy(payload, off, data, 0, data.length);
        return new Parsed(name, data, off, index, total, seriesNames, seriesSizes, false);
    }

    private static Parsed raw(byte[] payload) {
        return new Parsed(null, payload, 0, 0, 0, null, null, false);
    }

    private static Parsed parsePreamble(byte[] payload) {
        int total = ((payload[MAGIC_LEN] & 0xFF) << 8) | (payload[MAGIC_LEN + 1] & 0xFF);
        if (total < 1 || total > 0xFFFF) {
            return raw(payload);
        }
        int off = MAGIC_LEN + 2;
        String[] seriesNames = new String[total];
        long[] seriesSizes = new long[total];
        try {
            for (int i = 0; i < total; i++) {
                if (off + 2 > payload.length) {
                    throw new IllegalStateException("manifest truncated");
                }
                int ln = ((payload[off] & 0xFF) << 8) | (payload[off + 1] & 0xFF);
                if (ln < 1 || ln > NAME_MAX || off + 2 + ln + 4 > payload.length) {
                    throw new IllegalStateException("manifest name invalid");
                }
                String mn = new String(payload, off + 2, ln, StandardCharsets.UTF_8);
                validateName(mn);
                seriesNames[i] = mn;
                long s = ((payload[off + 2 + ln] & 0xFFL) << 24)
                        | ((payload[off + 3 + ln] & 0xFFL) << 16)
                        | ((payload[off + 4 + ln] & 0xFFL) << 8)
                        | (payload[off + 5 + ln] & 0xFFL);
                seriesSizes[i] = s;
                off += 2 + ln + 4;
            }
        } catch (RuntimeException e) {
            return raw(payload);
        }
        byte[] data = new byte[payload.length - off];
        return new Parsed(null, data, off, 0, total, seriesNames, seriesSizes, true);
    }

    private static boolean matches(byte[] p, byte[] magic) {
        for (int i = 0; i < magic.length; i++) {
            if (p[i] != magic[i]) {
                return false;
            }
        }
        return true;
    }

    public record Part(String base, int index, int total) {
    }

    private static final Pattern PART =
            Pattern.compile("\\.p(\\d{3})of(\\d{3})$");

    public static String partName(String base, int index, int total) {
        validateName(base);
        if (index < 1 || total < 1 || index > total) {
            throw new IllegalArgumentException("part index out of range: " + index + "/" + total);
        }
        if (total > 999) {
            throw new IllegalArgumentException("too many parts (>999): " + total);
        }
        String name = String.format(Locale.ROOT, "%s.p%03dof%03d", base, index, total);
        if (name.getBytes(StandardCharsets.UTF_8).length > NAME_MAX) {
            throw new IllegalArgumentException("part name too long: " + base);
        }
        return name;
    }

    public static Part parsePart(String name) {
        if (name == null) {
            return null;
        }
        Matcher m = PART.matcher(name);
        if (!m.find()) {
            return null;
        }
        int index = Integer.parseInt(m.group(1));
        int total = Integer.parseInt(m.group(2));
        if (index < 1 || total < 1 || index > total) {
            return null;
        }
        return new Part(name.substring(0, m.start()), index, total);
    }

    public static void validateName(String name) {
        if (name == null || name.isEmpty() || name.equals(".") || name.equals("..")) {
            throw new IllegalArgumentException("empty file name");
        }
        for (int i = 0; i < name.length(); i++) {
            char c = name.charAt(i);
            if (c < 0x20 || c == 0x7F || "\\/:*?\"<>|".indexOf(c) >= 0) {
                throw new IllegalArgumentException("file name has a forbidden character: " + name);
            }
        }
    }
}
