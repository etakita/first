package ru.vtb.streaming.player.codec;

import java.util.zip.CRC32;

public final class FrameCodec {

    private FrameCodec() {
    }

    /** CRC32 полезной нагрузки (32 бита). */
    public static long crc32(byte[] data) {
        CRC32 crc = new CRC32();
        crc.update(data);
        return crc.getValue();
    }

    public static long crc32c(byte[] data) {
        long crc = 0xFFFFFFFFL;
        for (byte b : data) {
            crc ^= (b & 0xFFL);
            for (int i = 0; i < 8; i++) {
                crc = ((crc & 1L) != 0) ? ((crc >>> 1) ^ 0x82F63B78L) : (crc >>> 1);
            }
        }
        return (crc ^ 0xFFFFFFFFL) & 0xFFFFFFFFL;
    }

    public static int[] buildBits(byte[] data) {
        return buildSymbols(data, ModConfig.MODE_2FSK);
    }

    public static int[] buildSymbols(byte[] data, ModConfig.Mode mode) {
        return buildSymbols(data, crc32(data), mode);
    }

    public static int[] buildSymbols(byte[] data, long crc, ModConfig.Mode mode) {
        return buildSymbols(data, crc, 0, mode);
    }

    public static int[] buildSymbols(byte[] data, long crc, long crc2, ModConfig.Mode mode) {
        int bps = mode.bitsPerSymbol;
        int total = mode.frameSymbols(data.length);
        int[] syms = new int[total];
        // Преамбула (16 символов, задана режимом)
        System.arraycopy(mode.preamble, 0, syms, 0, ModConfig.PREAMBLE_SYMBOLS);
        int pos = ModConfig.PREAMBLE_SYMBOLS;
        // Длина данных в байтах, 32 бита big-endian;
        // в chirp-режиме — LENGTH_REP повторов (побитовое голосование на приёме)
        for (int r = 0; r < (mode.chirp ? ModConfig.LENGTH_REP : 1); r++) {
            pos = writeField(syms, pos, data.length & 0xFFFFFFFFL, ModConfig.LENGTH_BITS, bps);
        }
        // Полезные данные — НЕПРЕРЫВНЫЙ битовый поток (MSB-first), дополненный
        // нулями в конце поля до границы символа (приёмник читает по
        // абсолютным позициям битов). Побайтовая запись с дополнением после
        // каждого байта была бы несовместима с frameBits при bps ∤ 8 (32fsk/64fsk).
        int dataBits = data.length * 8;
        int fieldBits = ModConfig.Mode.fieldBits(dataBits, bps);
        int acc = 0, n = 0;
        for (int i = 0; i < fieldBits; i++) {
            int bit = (i < dataBits) ? ((data[i >>> 3] >>> (7 - (i & 7))) & 1) : 0;
            acc = (acc << 1) | bit;
            if (++n == bps) {
                syms[pos++] = acc;
                acc = 0;
                n = 0;
            }
        }
        // CRC32 #1, 32 бита big-endian (+ CRC-32C #2 в режиме css);
        // в режиме css каждая сумма передаётся ДВАЖДЫ — хвостовой разрыв
        // ≤96 символов оставляет вторую копию хотя бы одной суммы
        pos = writeField(syms, pos, crc, ModConfig.CRC_BITS, bps);
        if (mode.chirp) {
            pos = writeField(syms, pos, crc2, ModConfig.CRC_BITS, bps);
            pos = writeField(syms, pos, crc, ModConfig.CRC_BITS, bps);
            pos = writeField(syms, pos, crc2, ModConfig.CRC_BITS, bps);
        }
        if (pos != total) {
            throw new IllegalStateException("Internal frame packing error: " + pos + " != " + total);
        }
        return syms;
    }

    private static int writeField(int[] syms, int pos, long value, int count, int bps) {
        int acc = 0, n = 0;
        for (int i = count - 1; i >= 0; i--) {
            acc = (acc << 1) | (int) ((value >>> i) & 1L);
            if (++n == bps) {
                syms[pos++] = acc;
                acc = 0;
                n = 0;
            }
        }
        while (n != 0) {
            acc <<= 1; // нулевое дополнение до границы символа
            if (++n == bps) {
                syms[pos++] = acc;
                acc = 0;
                n = 0;
            }
        }
        return pos;
    }
}
