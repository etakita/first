package ru.vtb.streaming.player.codec;

import java.util.zip.CRC32;

/**
 * Упаковка/контроль кадра:
 * <pre>
 *   [преамбула 16 символов][длина 32 бита][данные N байт][CRC32 32 бита]
 * </pre>
 * Все многобайтовые поля big-endian, биты внутри байта и внутри символа — MSB-first.
 * Режим 2fsk: 1 символ = 1 бит (символы и есть биты кадра).
 * Режим 4fsk:   1 символ = 2 бита (старший бит символа передаётся первым).
 * CRC32 (java.util.zip.CRC32) рассчитывается по байтам полезных данных.
 */
public final class FrameCodec {

    private FrameCodec() {
    }

    /** CRC32 полезной нагрузки (32 бита). */
    public static long crc32(byte[] data) {
        CRC32 crc = new CRC32();
        crc.update(data);
        return crc.getValue();
    }

    /**
     * Строит последовательность бит кадра из полезной нагрузки (режим 2fsk,
     * совместимость со старой сигнатурой).
     *
     * @param data передаваемые данные
     * @return int[] из 0/1 длиной {@link ModConfig#frameBits(int)}
     */
    public static int[] buildBits(byte[] data) {
        return buildSymbols(data, ModConfig.MODE_2FSK);
    }

    /**
     * Строит последовательность символов кадра из полезной нагрузки.
     *
     * @param data передаваемые данные
     * @param mode режим (2fsk: 1 бит/символ, 4fsk: 2 бита/символ)
     * @return int[] символов (индексы в {@link ModConfig.Mode#freqs})
     *         длиной {@link ModConfig.Mode#frameSymbols(int)}
     */
    public static int[] buildSymbols(byte[] data, ModConfig.Mode mode) {
        int bps = mode.bitsPerSymbol;
        int total = mode.frameSymbols(data.length);
        int[] syms = new int[total];
        // Преамбула (16 символов, задана режимом)
        System.arraycopy(mode.preamble, 0, syms, 0, ModConfig.PREAMBLE_SYMBOLS);
        int pos = ModConfig.PREAMBLE_SYMBOLS;
        // Длина данных в байтах, 32 бита big-endian
        pos = writeField(syms, pos, data.length & 0xFFFFFFFFL, ModConfig.LENGTH_BITS, bps);
        // Полезные данные
        for (byte b : data) {
            pos = writeField(syms, pos, b & 0xFFL, 8, bps);
        }
        // CRC32, 32 бита big-endian
        pos = writeField(syms, pos, crc32(data), ModConfig.CRC_BITS, bps);
        if (pos != total) {
            throw new IllegalStateException("Internal frame packing error: " + pos + " != " + total);
        }
        return syms;
    }

    /**
     * Записывает count бит значения value (MSB-first) в поток символов.
     * Каждый символ несёт bps бит (внутри символа — MSB-first).
     * count должен кратен bps.
     */
    private static int writeField(int[] syms, int pos, long value, int count, int bps) {
        int acc = 0, n = 0;
        for (int i = count - 1; i >= 0; i--) {
            acc = (acc << 1) | (int) ((value >>> i) & 1L);
            if (++n == bps) {
                syms[pos++] = acc;
                acc = 0;
                n = 0;
            }
        }
        if (n != 0) {
            throw new IllegalStateException("Field length " + count + " bits is not a multiple of " + bps);
        }
        return pos;
    }
}
