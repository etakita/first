package ru.vtb.streaming.player.codec;

/**
 * CPFSK-модулятор: частотная манипуляция с непрерывной фазой.
 *
 * Фаза накапливается непрерывно через границы символов (не сбрасывается), поэтому
 * на границах нет фазовых скачков — нет «щелчков» и широкополосного шума.
 * Тон строго в полосе FSK, неслышим для человека, но устойчив к прохождению
 * через аналоговый кабель и 16-битную квантизацию.
 *
 * Поддерживаются оба режима алфавита (2fsk: 2-FSK, 4fsk: 4-FSK) — частота
 * символа берётся из {@link ModConfig.Mode#freqs} по индексу символа.
 */
public final class FskModulator {

    private FskModulator() {
    }

    /**
     * Генерирует FSK-сигнал для заданной последовательности бит (режим 2fsk).
     *
     * @param bits      биты кадра (0/1)
     * @param amplitude амплитуда тона (обычно 1.0 — масштабирование α делается при микшировании)
     * @return float[] длиной bits.length * {@link ModConfig#SAMPLES_PER_SYMBOL}
     */
    public static float[] modulate(int[] bits, double amplitude) {
        return modulate(bits, amplitude, 0.0, ModConfig.MODE_2FSK);
    }

    /**
     * Генерирует FSK-сигнал для заданной последовательности символов.
     *
     * @param symbols   символы кадра (индексы в {@link ModConfig.Mode#freqs})
     * @param amplitude амплитуда тона (обычно 1.0)
     * @param mode      режим (алфавит частот)
     * @return float[] длиной symbols.length * {@link ModConfig#SAMPLES_PER_SYMBOL}
     */
    public static float[] modulate(int[] symbols, double amplitude, ModConfig.Mode mode) {
        return modulate(symbols, amplitude, 0.0, mode);
    }

    /**
     * Генерирует FSK-сигнал с заданной начальной фазой (для шаблонов преамбулы).
     *
     * @param initialPhase начальная фаза тона, рад
     */
    public static float[] modulate(int[] symbols, double amplitude, double initialPhase, ModConfig.Mode mode) {
        double sr = ModConfig.SAMPLE_RATE;
        int spp = ModConfig.SAMPLES_PER_SYMBOL;
        double twoPi = 2.0 * Math.PI;
        float[] out = new float[symbols.length * spp];
        double phase = initialPhase;
        int i = 0;
        for (int s : symbols) {
            double f = mode.freqs[s];
            double dPhase = twoPi * f / sr;
            for (int n = 0; n < spp; n++) {
                out[i++] = (float) (amplitude * Math.sin(phase));
                phase += dPhase;
                if (phase >= twoPi) {
                    phase -= twoPi; // удерживаем фазу в [0, 2π) — точность на длинных кадрах
                }
            }
        }
        return out;
    }
}
