package ru.vtb.streaming.player.codec;

/**
 * Константы схемы скрытого канала (CPFSK, ультразвук).
 *
 * Два режима работы:
 * <ul>
 *   <li><b>2fsk</b> — 2-FSK 17.5/18.5 кГц, 1 бит на символ, <b>100 бит/с</b>;</li>
 *   <li><b>4fsk</b> — 4-FSK 17.5/18.0/18.5/19.0 кГц, 2 бита на символ, <b>200 бит/с</b>
 *       (пропускная способность вдвое выше).</li>
 * </ul>
 *
 * В обоих режимах длительность символа = 10 мс = 441 сэмпел при 44100 Гц, и все
 * частоты FSK попадают ТОЧНО в бины БПФ (шаг сетки 44100/441 = 100 Гц):
 * 17500→175, 18000→180, 18500→185, 19000→190. Тон когерентен с окном символа —
 * это даёт максимальную устойчивость оценки энергии при поиске преамбулы и
 * демодуляции (устойчивость к расстройству ЦАП/АЦП до ±1 бина = ±100 Гц).
 *
 * Структура кадра (все многобайтовые поля big-endian, биты внутри байта — MSB-first,
 * биты внутри символа — MSB-first):
 * <pre>
 *   [преамбула 16 символов][длина 32 бита][данные N байт][CRC32 32 бита]
 * </pre>
 * 2fsk: 1 символ = 1 бит → всего 80 + 8N бит (кадр = 80 + 8N окон по 10 мс);
 * 4fsk: 1 символ = 2 бита → всего 96 + 8N бит (кадр = 48 + 4N окон по 10 мс) —
 * при значимой полезной нагрузке время передачи вдвое меньше.
 *
 * Преамбулы режимов различны и взаимно «ортогональны»:
 *   2fsk — биты 1010… (тоны 18.5/17.5 кГц, начинается с верхней группы);
 *   4fsk — символы 0110… (тоны 18.0/18.5 кГц, начинается с нижней группы).
 * Частоты 4fsk-алфавита {17.5, 18.0, 18.5, 19.0} содержат 2fsk-алфавит
 * {17.5, 18.5}, поэтому единый грубый скан (Гёрцель по 4 частотам 4fsk) видит
 * преамбулы обоих режимов, а точное различение — по шаблону преамбулы
 * (свёртка) + БПФ-верификации. Это даёт приёмнику автоопределение режима.
 */
public final class ModConfig {

    private ModConfig() {
    }

    /** Частота дискретизации скрытого канала, Гц. */
    public static final double SAMPLE_RATE = 44100.0;

    /** Длительность символа в сэмпелах: 44100 / 100 = 441 (10 мс). */
    public static final int SAMPLES_PER_SYMBOL = 441;

    /** Длительность бита в сэмпелах (режим 2fsk, символ = бит; совместимость). */
    public static final int SAMPLES_PER_BIT = SAMPLES_PER_SYMBOL;

    /** Преамбула: 16 символов (в 2fsk — 16 бит). */
    public static final int PREAMBLE_SYMBOLS = 16;

    /** Преамбула в битах (режим 2fsk; совместимость). */
    public static final int PREAMBLE_BITS = PREAMBLE_SYMBOLS;

    /** Поле длины данных в байтах, бит. */
    public static final int LENGTH_BITS = 32;

    /** Контрольная сумма CRC32, бит. */
    public static final int CRC_BITS = 32;

    /** Преамбула + заголовок, бит (режим 2fsk; совместимость). */
    public static final int HEADER_BITS = PREAMBLE_SYMBOLS + LENGTH_BITS;

    /** Минимальная абсолютная энергия символа для признания его «видимым» (нормированная |X|^2/N^2). */
    public static final double DETECT_MIN_POWER = 5.0e-6;

    /** Минимальный контраст max(P)/secondMax(P) для признания символа уверенным (~7.8 дБ). */
    public static final double DETECT_MIN_CONTRAST = 6.0;

    /** Частоты логического 0/1 режима 2fsk (совместимость). */
    public static final double FREQ_0 = 17500.0;
    public static final double FREQ_1 = 18500.0;

    /**
     * Настройка режима: алфавит FSK, преамбула, биты на символ.
     */
    public static final class Mode {
        /** Имя режима: "2fsk" или "4fsk". */
        public final String name;
        /** Число бит на символ (1 или 2). */
        public final int bitsPerSymbol;
        /** Частоты FSK по возрастанию, Гц (все точно на бинах 100 Гц). */
        public final double[] freqs;
        /** Частоты FSK в бинах (freqs / 100 Гц). */
        public final int[] bins;
        /** Преамбула: 16 символов (значения — индексы в freqs). */
        public final int[] preamble;
        /** Пропускная способность, бит/с. */
        public final double bitRate;

        Mode(String name, int bitsPerSymbol, double[] freqs, int[] preamble) {
            this.name = name;
            this.bitsPerSymbol = bitsPerSymbol;
            this.freqs = freqs;
            this.preamble = preamble;
            this.bins = new int[freqs.length];
            for (int i = 0; i < freqs.length; i++) {
                this.bins[i] = (int) Math.round(freqs[i] / (SAMPLE_RATE / SAMPLES_PER_SYMBOL));
            }
            this.bitRate = (SAMPLE_RATE / SAMPLES_PER_SYMBOL) * bitsPerSymbol;
        }

        /** Число символов кадра для заданного размера полезной нагрузки. */
        public int frameSymbols(int dataBytes) {
            return PREAMBLE_SYMBOLS + LENGTH_BITS / bitsPerSymbol
                    + dataBytes * 8 / bitsPerSymbol + CRC_BITS / bitsPerSymbol;
        }

        /** Число бит кадра для заданного размера полезной нагрузки. */
        public int frameBits(int dataBytes) {
            return frameSymbols(dataBytes) * bitsPerSymbol;
        }

        /** Число сэмпел кадра (без учёта lead/tail). */
        public int frameSamples(int dataBytes) {
            return frameSymbols(dataBytes) * SAMPLES_PER_SYMBOL;
        }

        /** Число бит заголовка (преамбула + поле длины). */
        public int headerBits() {
            return PREAMBLE_SYMBOLS * bitsPerSymbol + LENGTH_BITS;
        }

        /**
         * Группа символа для единого поиска преамбулы:
         * 0 — нижняя половина алфавита, 1 — верхняя.
         * Преамбулы обоих режимов чередуют группы, поэтому один и тот же
         * «цепочечный» скан находит оба режима.
         */
        public int group(int symbol) {
            return symbol < freqs.length / 2 ? 0 : 1;
        }

        @Override
        public String toString() {
            return name;
        }
    }

    /** Режим 2fsk: 2-FSK 17.5/18.5 кГц, 1 бит/символ, 100 бит/с. */
    public static final Mode MODE_2FSK = new Mode(
            "2fsk", 1,
            new double[]{FREQ_0, FREQ_1},
            new int[]{1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0});

    /**
     * Режим 4fsk: 4-FSK 17.5/18.0/18.5/19.0 кГц, 2 бита/символ, 200 бит/с.
     * Преамбула — чередующиеся символы 1 и 2 (тоны 18.0/18.5 кГц):
     * отличается от преамбулы 2fsk (18.5/17.5 кГц), поэтому режимы
     * не «перехватывают» преамбулы друг друга и различаются автоматически.
     */
    public static final Mode MODE_4FSK = new Mode(
            "4fsk", 2,
            new double[]{17500.0, 18000.0, 18500.0, 19000.0},
            new int[]{1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2});

    /** Все режимы; порядок = приоритет при автоопределении. */
    public static final Mode[] ALL = {MODE_2FSK, MODE_4FSK};

    /**
     * Единый алфавит грубого скана: частоты 4fsk (супермножество 2fsk).
     * Окно с тоном любого режима «видно» Гёрцелем хотя бы на одной из них.
     */
    public static final double[] SCAN_FREQS = MODE_4FSK.freqs;

    /** Режим по имени (без учёта регистра); бросает IllegalArgumentException. */
    public static Mode byName(String s) {
        if (s == null) {
            throw new IllegalArgumentException("Mode not set");
        }
        for (Mode m : ALL) {
            if (m.name.equalsIgnoreCase(s)) {
                return m;
            }
        }
        throw new IllegalArgumentException("Unknown mode: " + s + " (available: 2fsk, 4fsk)");
    }

    /**
     * Число бит кадра для заданного размера полезной нагрузки (режим 2fsk,
     * совместимость со старой сигнатурой).
     */
    public static int frameBits(int dataBytes) {
        return MODE_2FSK.frameBits(dataBytes);
    }

    /**
     * Число сэмпел кадра (режим 2fsk, совместимость со старой сигнатурой).
     */
    public static int frameSamples(int dataBytes) {
        return MODE_2FSK.frameSamples(dataBytes);
    }
}
