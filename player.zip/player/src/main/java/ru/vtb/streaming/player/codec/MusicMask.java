package ru.vtb.streaming.player.codec;

public final class MusicMask implements ChirpMask {

    private static final double[][] BANDS = {
            {0, 1000}, {1000, 2000}, {2000, 4000}, {4000, 6000},
            {6000, 8200}, {8200, 12250}, {12250, 16500}, {16500, 22050}};
    private static final double[] TH_ABS_DB = {-45, -40, -35, -30, -25, -20, -15, -10};

    private static final double SAFETY = 0.7;

    private static final int N = 256;
    private static final int HOP = 128;

    private final int wins;
    private final float[] binPow;
    private final float[] thAmp;
    private final double k;

    public MusicMask(float[] mono, int regionLenSamples, double k) {
        this.k = k;
        int nb = N / 2 + 1;
        this.wins = Math.max(1, (regionLenSamples + HOP - 1) / HOP);
        this.binPow = new float[wins * nb];

        double[] win = new double[N];
        double neff = 0.0;
        for (int i = 0; i < N; i++) {
            win[i] = 0.5 * (1.0 - Math.cos(2.0 * Math.PI * i / (N - 1)));
            neff += win[i];
        }
        double invNeff2 = 2.0 / (neff * neff);

        double[] re = new double[N];
        double[] im = new double[N];
        for (int w = 0; w < wins; w++) {
            int start = w * HOP;
            for (int i = 0; i < N; i++) {
                int s = start + i;
                re[i] = (s < mono.length) ? mono[s] * win[i] : 0.0;
                im[i] = 0.0;
            }
            fft(re, im);
            for (int b = 0; b < nb; b++) {
                binPow[w * nb + b] = (float) (invNeff2 * (re[b] * re[b] + im[b] * im[b]));
            }
        }

        this.thAmp = new float[nb];
        double sr = ModConfig.SAMPLE_RATE;
        for (int b = 0; b < nb; b++) {
            double f = b * sr / N;
            double amp = Math.pow(10.0, TH_ABS_DB[BANDS.length - 1] / 20.0);
            for (int i = 0; i < BANDS.length; i++) {
                if (f >= BANDS[i][0] && f < BANDS[i][1]) {
                    amp = Math.pow(10.0, TH_ABS_DB[i] / 20.0);
                    break;
                }
            }
            thAmp[b] = (float) amp;
        }
    }

    @Override
    public double scale(int framePos, double freq) {
        int nb = N / 2 + 1;
        double sr = ModConfig.SAMPLE_RATE;
        int b0 = (int) (freq * N / sr);
        if (b0 < 0) {
            b0 = 0;
        } else if (b0 >= nb) {
            b0 = nb - 1;
        }
        int b1 = Math.min(b0 + 1, nb - 1);
        double frac = freq * N / sr - b0;

        int wi = framePos / HOP;
        if (wi < 0) {
            wi = 0;
        } else if (wi >= wins) {
            wi = wins - 1;
        }
        int w1 = Math.min(wi + 1, wins - 1);
        double tf = (framePos - wi * HOP) / (double) HOP;

        double pb0 = binPow[wi * nb + b0] * (1 - tf) + binPow[w1 * nb + b0] * tf;
        double p = (b0 == b1) ? pb0
                : pb0 * (1 - frac) + (binPow[wi * nb + b1] * (1 - tf) + binPow[w1 * nb + b1] * tf) * frac;

        double m = Math.sqrt(Math.max(0.0, p));
        double a = k * m;
        double t = thAmp[b0];
        if (a < t) {
            a = t;
        }
        return SAFETY * a;
    }

    private static void fft(double[] re, double[] im) {
        int n = re.length;
        for (int i = 1, j = 0; i < n; i++) {
            int bit = n >> 1;
            for (; (j & bit) != 0; bit >>= 1) {
                j ^= bit;
            }
            j ^= bit;
            if (i < j) {
                double tr = re[i];
                re[i] = re[j];
                re[j] = tr;
                double ti = im[i];
                im[i] = im[j];
                im[j] = ti;
            }
        }
        for (int len = 2; len <= n; len <<= 1) {
            double ang = -2.0 * Math.PI / len;
            double wr = Math.cos(ang);
            double wi = Math.sin(ang);
            for (int i = 0; i < n; i += len) {
                double cwr = 1.0, cwi = 0.0;
                int half = len >> 1;
                for (int kk = 0; kk < half; kk++) {
                    int a = i + kk, b = a + half;
                    double ur = re[a], ui = im[a];
                    double vr = re[b] * cwr - im[b] * cwi;
                    double vi = re[b] * cwi + im[b] * cwr;
                    re[a] = ur + vr;
                    im[a] = ui + vi;
                    re[b] = ur - vr;
                    im[b] = ui - vi;
                    double nwr = cwr * wr - cwi * wi;
                    cwi = cwr * wi + cwi * wr;
                    cwr = nwr;
                }
            }
        }
    }
}
