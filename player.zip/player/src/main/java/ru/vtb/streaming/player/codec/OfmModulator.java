package ru.vtb.streaming.player.codec;

public final class OfmModulator {

    private OfmModulator() {
    }

    public static final int SR = 44100;
    public static final int NFFT = 256;
    public static final int CP = 16;
    public static final int SYM_LEN = NFFT + CP;
    public static final int NSUBC = 32;
    public static final int FIRST_BIN = 93;
    public static final int NDATA_SUBC = NSUBC - 2;
    public static volatile int DATA_SUBC = NDATA_SUBC;
    public static final double CARRIER_AMP = 2.0;
    public static final int BITS_PER_SUBC = 4;
    public static final int BITS_PER_SYM = NDATA_SUBC * BITS_PER_SUBC;
    public static final int PREAMBLE_SYMS = 16;
    public static final int PILOT_EVERY = 64;
    public static final int PILOT_SYMS = 4;
    public static final int PREAMBLE_POINT = 0;
    public static final double DEFAULT_AMPLITUDE = Math.pow(10.0, -45.0 / 20.0);

    public static double[] qamIQ(int qam) {
        double[] lv = new double[qam];
        if (qam == 2) {
            lv[0] = -1.0 / Math.sqrt(2.0);
            lv[1] = +1.0 / Math.sqrt(2.0);
        } else {
            for (int i = 0; i < 4; i++) {
                lv[i] = (2 * i - 3) / Math.sqrt(10.0);
            }
        }
        return lv;
    }

    public static int bitsPerSubc(int qam) {
        return 2 * (int) (Math.log(qam) / Math.log(2) + 0.5);
    }

    public static float[] modulate(byte[] data, long crc1, long crc2, double amplitude) {
        return modulate(data, crc1, crc2, amplitude, 4);
    }

    public static int[] pilotStarts(int mSyms) {
        int n = mSyms / PILOT_EVERY + 1;
        int[] starts = new int[n];
        int pos = PREAMBLE_SYMS;
        for (int i = 0; i < n; i++) {
            int block = Math.min(PILOT_EVERY, mSyms - i * PILOT_EVERY);
            pos += block;
            starts[i] = pos;
            pos += PILOT_SYMS;
        }
        return starts;
    }

    public static float[] modulate(byte[] data, long crc1, long crc2, double amplitude, int qam) {
        return modulate(data, crc1, crc2, amplitude, qam, DATA_SUBC);
    }

    public static float[] modulate(byte[] data, long crc1, long crc2, double amplitude, int qam, int dataSubc) {
        return modulate(data, crc1, crc2, amplitude, qam, dataSubc, true);
    }

    public static float[] modulate(byte[] data, long crc1, long crc2, double amplitude, int qam, int dataSubc, boolean interleaved) {
        return modulate(data, crc1, crc2, amplitude, qam, dataSubc, interleaved, null);
    }

    public static float[] modulate(byte[] data, long crc1, long crc2, double amplitude, int qam, int dataSubc, boolean interleaved, byte[] orig) {
        double[] lv = qamIQ(qam);
        int bitsSubc = bitsPerSubc(qam);
        int bitsSym = dataSubc * bitsSubc;
        double[] qamI = new double[qam * qam];
        double[] qamQ = new double[qam * qam];
        for (int i = 0; i < qam * qam; i++) {
            int r = i / qam, c = i % qam;
            qamI[i] = lv[c];
            qamQ[i] = lv[r];
        }
        int[] frameBits = FrameCodec.buildFrameBits(data, crc1, crc2, interleaved, orig);
        int mSyms = (frameBits.length + bitsSym - 1) / bitsSym;
        int nPilots = mSyms / PILOT_EVERY + 1;
        int totalSyms = PREAMBLE_SYMS + mSyms + nPilots * PILOT_SYMS;
        float[] out = new float[totalSyms * SYM_LEN];

        float[] preambleT = buildPilotSymbol(lv);

        int pos = 0;
        for (int s = 0; s < PREAMBLE_SYMS; s++) {
            System.arraycopy(preambleT, 0, out, pos, SYM_LEN);
            pos += SYM_LEN;
        }

        for (int s = 0; s < mSyms; s++) {
            double[] iRe = new double[NSUBC];
            double[] iIm = new double[NSUBC];
            iRe[0] = iRe[NSUBC - 1] = CARRIER_AMP * lv[PREAMBLE_POINT];
            iIm[0] = iIm[NSUBC - 1] = CARRIER_AMP * lv[PREAMBLE_POINT];
            for (int d = 0; d < dataSubc; d++) {
                int sub = d + 1;
                int bitPos = s * bitsSym + d * bitsSubc;
                int val = 0;
                for (int k = 0; k < bitsSubc; k++) {
                    val <<= 1;
                    if (bitPos + k < frameBits.length) {
                        val |= frameBits[bitPos + k];
                    }
                }
                iRe[sub] = qamI[val];
                iIm[sub] = qamQ[val];
            }
            float[] symT = buildSymbolTimeVec(iRe, iIm);
            System.arraycopy(symT, 0, out, pos, SYM_LEN);
            pos += SYM_LEN;
            if ((s + 1) % PILOT_EVERY == 0 || s == mSyms - 1) {
                for (int p = 0; p < PILOT_SYMS; p++) {
                    System.arraycopy(preambleT, 0, out, pos, SYM_LEN);
                    pos += SYM_LEN;
                }
            }
        }

        double peak = 0.0;
        for (float v : out) {
            double a = Math.abs(v);
            if (a > peak) {
                peak = a;
            }
        }
        if (peak > 1e-9) {
            for (int i = 0; i < out.length; i++) {
                out[i] *= (float) (amplitude / peak);
            }
        }
        return out;
    }

    private static float[] buildSymbolTimeVec(double[] iRe, double[] iIm) {
        double[] xRe = new double[NFFT];
        double[] xIm = new double[NFFT];
        for (int b = 0; b < NSUBC; b++) {
            int bin = FIRST_BIN + b;
            xRe[bin] = iRe[b];
            xIm[bin] = iIm[b];
            int nb = NFFT - bin;
            xRe[nb] = iRe[b];
            xIm[nb] = -iIm[b];
        }
        return ifftReal(xRe, xIm);
    }

    private static float[] buildPilotSymbol(double[] lv) {
        double[] iRe = new double[NSUBC];
        double[] iIm = new double[NSUBC];
        for (int b = 0; b < NSUBC; b++) {
            double amp = (b == 0 || b == NSUBC - 1) ? CARRIER_AMP : 1.0;
            iRe[b] = amp * lv[PREAMBLE_POINT];
            iIm[b] = amp * lv[PREAMBLE_POINT];
        }
        return buildSymbolTimeVec(iRe, iIm);
    }

    private static float[] ifftReal(double[] xRe, double[] xIm) {
        int n = NFFT;
        double[] re = xRe.clone();
        double[] im = xIm.clone();
        int bits = Integer.numberOfTrailingZeros(n);
        for (int i = 0; i < n; i++) {
            int r = bitReverse(i, bits);
            if (r > i) {
                double tr = re[i]; re[i] = re[r]; re[r] = tr;
                double ti = im[i]; im[i] = im[r]; im[r] = ti;
            }
        }
        for (int len = 2; len <= n; len <<= 1) {
            double ang = 2.0 * Math.PI / len;
            double wRe = Math.cos(ang), wIm = Math.sin(ang);
            for (int i = 0; i < n; i += len) {
                double curRe = 1.0, curIm = 0.0;
                for (int j = 0; j < len / 2; j++) {
                    int u = i + j;
                    int v = i + j + len / 2;
                    double tRe = curRe * re[v] - curIm * im[v];
                    double tIm = curRe * im[v] + curIm * re[v];
                    re[v] = re[u] - tRe;
                    im[v] = im[u] - tIm;
                    re[u] += tRe;
                    im[u] += tIm;
                    double nRe = curRe * wRe - curIm * wIm;
                    curIm = curRe * wIm + curIm * wRe;
                    curRe = nRe;
                }
            }
        }
        double scale = 1.0;
        double s = 1.0 / Math.sqrt(n);
        float[] t = new float[n];
        for (int i = 0; i < n; i++) {
            t[i] = (float) (re[i] * s);
        }
        float[] out = new float[n + CP];
        System.arraycopy(t, n - CP, out, 0, CP);
        System.arraycopy(t, 0, out, CP, n);
        return out;
    }

    private static int bitReverse(int x, int bits) {
        int r = 0;
        for (int i = 0; i < bits; i++) {
            r = (r << 1) | (x & 1);
            x >>= 1;
        }
        return r;
    }
}
