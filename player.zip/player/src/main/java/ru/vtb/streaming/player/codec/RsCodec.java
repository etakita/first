package ru.vtb.streaming.player.codec;

import java.util.Arrays;

public final class RsCodec {

    public static final int N = 255;
    public static final int K = 207;
    public static final int PARITY = 48;
    public static final int T = PARITY / 2;

    private static final int GF_SIZE = 256;
    private static final int GF_POLY = 0x11D;
    private static final int GF_PERIOD = GF_SIZE - 1;

    private static final int[] EXP = new int[2 * GF_PERIOD];
    private static final int[] LOG = new int[GF_SIZE];

    static {
        int x = 1;
        for (int i = 0; i < GF_PERIOD; i++) {
            EXP[i] = x;
            LOG[x] = i;
            x <<= 1;
            if ((x & GF_SIZE) != 0) {
                x ^= GF_POLY;
            }
        }
        for (int i = GF_PERIOD; i < EXP.length; i++) {
            EXP[i] = EXP[i - GF_PERIOD];
        }
    }

    private static final int[] GEN = buildGen();

    private RsCodec() {
    }

    private static int mul(int a, int b) {
        return (a == 0 || b == 0) ? 0 : EXP[LOG[a] + LOG[b]];
    }

    private static int inv(int a) {
        if (a == 0) {
            throw new ArithmeticException("GF(256): inverse of zero");
        }
        return EXP[GF_PERIOD - LOG[a]];
    }

    private static int[] buildGen() {
        int[] g = {1};
        for (int i = 1; i <= PARITY; i++) {
            int a = EXP[i];
            int[] ng = new int[g.length + 1];
            for (int j = 0; j <= g.length; j++) {
                int v = (j < g.length) ? mul(a, g[j]) : 0;
                if (j > 0) {
                    v ^= g[j - 1];
                }
                ng[j] = v;
            }
            g = ng;
        }
        return g;
    }

    public static int encodedLength(int dataBytes) {
        if (dataBytes < 0) {
            throw new IllegalArgumentException("dataBytes < 0");
        }
        int full = dataBytes / K;
        int r = dataBytes % K;
        return full * N + (r == 0 ? 0 : r + PARITY);
    }

    public static byte[] encode(byte[] data) {
        if (data == null) {
            throw new IllegalArgumentException("data == null");
        }
        byte[] out = new byte[encodedLength(data.length)];
        int op = 0;
        for (int off = 0; off < data.length; off += K) {
            int r = Math.min(K, data.length - off);
            encodeBlock(data, off, r, out, op);
            op += (r == K) ? N : (r + PARITY);
        }
        return out;
    }

    public static byte[] decode(byte[] wire, double[] quality, double erasureBelow) {
        if (wire == null) {
            throw new IllegalArgumentException("wire == null");
        }
        if (wire.length == 0) {
            return new byte[0];
        }
        int total = 0;
        for (int off = 0; off < wire.length; ) {
            int rem = wire.length - off;
            int r = (rem >= N) ? K : (rem - PARITY);
            if (r < 1 || r > K) {
                throw new IllegalArgumentException("Invalid RS block length: " + rem);
            }
            total += r;
            off += (rem >= N) ? N : rem;
        }
        byte[] out = new byte[total];
        int op = 0;
        for (int off = 0; off < wire.length; ) {
            int rem = wire.length - off;
            int r = (rem >= N) ? K : (rem - PARITY);
            byte[] fullWire = new byte[N];
            System.arraycopy(wire, off, fullWire, 0, r);
            System.arraycopy(wire, off + r, fullWire, K, PARITY);
            double[] fq = new double[N];
            Arrays.fill(fq, Double.POSITIVE_INFINITY);
            if (quality != null) {
                for (int i = 0; i < r; i++) {
                    fq[i] = quality[off + i];
                }
                for (int i = 0; i < PARITY; i++) {
                    fq[K + i] = quality[off + r + i];
                }
            }
            byte[] dec;
            try {
                dec = decodeBlock(fullWire, fq, 1e-9);
            } catch (RuntimeException bmFail) {
                dec = decodeBlock(fullWire, fq, erasureBelow);
            }
            System.arraycopy(dec, 0, out, op, r);
            op += r;
            off += (rem >= N) ? N : rem;
        }
        return out;
    }

    private static void encodeBlock(byte[] data, int off, int r, byte[] out, int opos) {
        int[] d = new int[N];
        for (int i = 0; i < K; i++) {
            d[2 * T + K - 1 - i] = (i < r) ? (data[off + i] & 0xFF) : 0;
        }
        int[] rem = d.clone();
        for (int i = N - 1; i >= 2 * T; i--) {
            int coef = rem[i];
            if (coef != 0) {
                for (int j = 0; j <= PARITY; j++) {
                    rem[i - PARITY + j] ^= (j == PARITY) ? coef : mul(coef, GEN[j]);
                }
            }
        }
        for (int p = 0; p < r; p++) {
            out[opos + p] = (byte) d[N - 1 - p];
        }
        for (int p = 0; p < PARITY; p++) {
            out[opos + r + p] = (byte) rem[PARITY - 1 - p];
        }
    }

    private static byte[] decodeBlock(byte[] wire, double[] q, double erasureBelow) {
        int[] c = new int[N];
        for (int p = 0; p < N; p++) {
            c[N - 1 - p] = wire[p] & 0xFF;
        }

        int[] S = syndromes(c);
        if (isZero(S)) {
            return toWire(c);
        }

        int[] erasDeg = selectErasures(q, erasureBelow);
        int r = erasDeg.length;
        int[] le = {1};
        for (int d : erasDeg) {
            int X = EXP[d % GF_PERIOD];
            int[] nl = new int[le.length + 1];
            for (int i = le.length - 1; i >= 0; i--) {
                nl[i] ^= le[i];
                nl[i + 1] ^= mul(X, le[i]);
            }
            le = nl;
        }

        int[] T = new int[PARITY + 1];
        for (int j = 1; j <= PARITY; j++) {
            int v = S[j];
            for (int i = 1; i < le.length; i++) {
                int sm = j - i;
                int sv = (sm >= 1) ? S[sm] : (sm == 0 ? 1 : 0);
                v ^= mul(le[i], sv);
            }
            T[j] = v;
        }

        int count = PARITY - r;
        int[] U = new int[count + 1];
        for (int n = 1; n <= count; n++) {
            U[n] = T[r + n];
        }
        int[] cr = berlekampMassey(U, count);
        int L = cr.length - 1;
        while (L > 0 && cr[L] == 0) {
            L--;
        }
        int maxErrs = (PARITY - r) / 2;
        if (L > maxErrs) {
            throw new RuntimeException("RS: more than " + maxErrs
                    + " unmarked byte errors in a block (" + r + " erasures)");
        }

        int[] la = new int[le.length + cr.length - 1];
        for (int i = 0; i < le.length; i++) {
            for (int j = 0; j < cr.length; j++) {
                la[i + j] ^= mul(le[i], cr[j]);
            }
        }
        int ld = la.length - 1;
        while (ld > 0 && la[ld] == 0) {
            ld--;
        }
        int m = r + L;
        int[] locs = new int[m];
        int ne = 0;
        for (int d = 0; d < N; d++) {
            int v = 0;
            for (int i = 0; i <= ld; i++) {
                v ^= mul(la[i], EXP[i * d % GF_PERIOD]);
            }
            if (v == 0 && ne < m) {
                locs[ne++] = (255 - d) % 255;
            }
        }
        if (ne != m) {
            throw new RuntimeException("RS: locator roots mismatch");
        }

        int[][] A = new int[m][m];
        for (int j = 0; j < m; j++) {
            for (int i = 0; i < m; i++) {
                A[j][i] = EXP[(j + 1) * locs[i] % GF_PERIOD];
            }
        }
        int[] rhs = Arrays.copyOfRange(S, 1, m + 1);
        int[] ev = gfSolve(A, rhs);
        if (ev == null) {
            throw new RuntimeException("RS: value matrix is singular");
        }
        for (int i = 0; i < m; i++) {
            c[locs[i]] ^= ev[i];
        }
        if (!isZero(syndromes(c))) {
            throw new RuntimeException("RS: residual errors after correction");
        }
        return toWire(c);
    }

    private static int[] syndromes(int[] c) {
        int[] S = new int[PARITY + 1];
        for (int j = 1; j <= PARITY; j++) {
            int v = 0;
            for (int d = 0; d < N; d++) {
                if (c[d] != 0) {
                    v ^= mul(c[d], EXP[j * d % GF_PERIOD]);
                }
            }
            S[j] = v;
        }
        return S;
    }

    private static int[] selectErasures(double[] q, double erasureBelow) {
        if (q == null) {
            return new int[0];
        }
        int[] cand = new int[N];
        int nc = 0;
        for (int p = 0; p < N; p++) {
            if (q[p] < erasureBelow) {
                cand[nc++] = N - 1 - p;
            }
        }
        if (nc == 0) {
            return new int[0];
        }
        if (nc <= PARITY) {
            return Arrays.copyOf(cand, nc);
        }
        Integer[] idx = new Integer[nc];
        for (int i = 0; i < nc; i++) {
            idx[i] = i;
        }
        Arrays.sort(idx, (a, b) -> Double.compare(q[N - 1 - cand[a]], q[N - 1 - cand[b]]));
        int[] res = new int[PARITY];
        for (int i = 0; i < PARITY; i++) {
            res[i] = cand[idx[i]];
        }
        return res;
    }

    private static int[] berlekampMassey(int[] S, int count) {
        int[] C = {1};
        int[] B = {1};
        int L = 0;
        int m = 1;
        int b = 1;
        for (int n = 1; n <= count; n++) {
            int d = S[n];
            for (int i = 1; i < C.length; i++) {
                d ^= mul(C[i], S[n - i]);
            }
            if (d == 0) {
                m++;
                continue;
            }
            int[] Csave = C;
            int coef = mul(d, inv(b));
            int len = Math.max(C.length, B.length + m);
            int[] Cnew = new int[len];
            System.arraycopy(C, 0, Cnew, 0, C.length);
            for (int i = 0; i < B.length; i++) {
                Cnew[i + m] ^= mul(coef, B[i]);
            }
            if (2 * L < n) {
                L = n - L;
                B = Csave;
                b = d;
                m = 1;
            } else {
                m++;
            }
            C = Cnew;
        }
        return C;
    }

    private static int[] gfSolve(int[][] A, int[] rhs) {
        int r = rhs.length;
        for (int col = 0; col < r; col++) {
            int piv = -1;
            for (int row = col; row < r; row++) {
                if (A[row][col] != 0) {
                    piv = row;
                    break;
                }
            }
            if (piv < 0) {
                return null;
            }
            if (piv != col) {
                int[] t = A[piv];
                A[piv] = A[col];
                A[col] = t;
                int tv = rhs[piv];
                rhs[piv] = rhs[col];
                rhs[col] = tv;
            }
            int ip = inv(A[col][col]);
            for (int j = col; j < r; j++) {
                A[col][j] = mul(A[col][j], ip);
            }
            rhs[col] = mul(rhs[col], ip);
            for (int row = 0; row < r; row++) {
                if (row == col || A[row][col] == 0) {
                    continue;
                }
                int f = A[row][col];
                for (int j = col; j < r; j++) {
                    A[row][j] ^= mul(f, A[col][j]);
                }
                rhs[row] ^= mul(f, rhs[col]);
            }
        }
        return rhs;
    }

    private static boolean isZero(int[] v) {
        for (int x : v) {
            if (x != 0) {
                return false;
            }
        }
        return true;
    }

    private static byte[] toWire(int[] c) {
        byte[] w = new byte[N];
        for (int p = 0; p < N; p++) {
            w[p] = (byte) c[N - 1 - p];
        }
        return w;
    }
}
