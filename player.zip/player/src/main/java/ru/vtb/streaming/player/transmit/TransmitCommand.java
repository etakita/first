package ru.vtb.streaming.player.transmit;

import ru.vtb.streaming.player.Args;
import ru.vtb.streaming.player.audio.Resampler;
import ru.vtb.streaming.player.audio.WavData;
import ru.vtb.streaming.player.audio.WavFile;
import ru.vtb.streaming.player.codec.ChirpMask;
import ru.vtb.streaming.player.codec.Stealth;
import ru.vtb.streaming.player.codec.FrameCodec;
import ru.vtb.streaming.player.codec.MusicMask;
import ru.vtb.streaming.player.codec.FskModulator;
import ru.vtb.streaming.player.codec.ModConfig;
import ru.vtb.streaming.player.codec.RsCodec;
import ru.vtb.streaming.player.util.TimeFmt;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.Mixer;
import javax.sound.sampled.SourceDataLine;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.logging.Logger;

public final class TransmitCommand {

    private static final Logger LOG = Logger.getLogger("player.transmit");
    private static final double SR = ModConfig.SAMPLE_RATE;
    private static final double PEAK_LIMIT = 0.98;
    private static final double PLAY_MARGIN_S = 1.0;

    public int run(String[] args) {
        try {
            Args a = new Args(args);
            Path musicPath = Path.of(a.req("music"));
            Path dataPath = Path.of(a.req("data"));
            String outArg = a.str("output", null);
            double alpha = a.num("alpha", 0.05);
            double maskK = a.num("mask-k", 0.0);
            double usAmpDb = a.num("us-amp", -45.0);
            int usQam = (int) a.num("us-qam", 2.0);
            int usSubc = (int) a.num("us-subc", 30.0);
            boolean usInterleave = a.bool("us-interleave", true);
            double musicGainDb = a.num("music-gain", 0.0);
            long seed = (long) a.num("seed", 0.0);
            double lead = a.num("lead", 0.5);
            double tail = a.num("tail", 0.5);
            boolean play = a.flag("play");
            String device = a.str("device", null);
            ModConfig.Mode mode;
            try {
                mode = ModConfig.byName(a.str("mode", ModConfig.MODE_2FSK.name));
            } catch (IllegalArgumentException e) {
                LOG.severe(e.getMessage());
                return 1;
            }

            if (outArg == null && !play) {
                LOG.severe("Neither --output nor --play is set - nowhere to write/play the signal");
                return 1;
            }
            if (alpha <= 0.0 || alpha > 0.5) {
                LOG.severe("Mixing coefficient --alpha must be in the range (0, 0.5]");
                return 1;
            }
            if (lead < 0.0 || tail < 0.0) {
                LOG.severe("--lead/--tail must not be negative");
                return 1;
            }
            if (maskK < 0.0 || maskK > 0.5) {
                LOG.severe("Mask coefficient --mask-k must be in the range [0, 0.5]");
                return 1;
            }
            if (maskK > 0.0 && !ModConfig.byName(a.str("mode", ModConfig.MODE_2FSK.name)).chirp) {
                LOG.severe("--mask-k is only supported in CSS (chirp) modes");
                return 1;
            }

            WavData music = WavFile.read(musicPath);
            LOG.info(String.format("Music: %s - %d Hz, %d ch, %s",
                    musicPath, music.sampleRate, music.channelCount(),
                    TimeFmt.seconds(music.frameCount() / (double) music.sampleRate)));

            byte[] data;
            try {
                data = Files.readAllBytes(dataPath);
            } catch (java.nio.file.NoSuchFileException e) {
                LOG.severe("Data file not found: " + dataPath);
                return 1;
            }
            LOG.info("Data: " + dataPath + " - " + data.length + " bytes");

            WavData music44 = Resampler.resample(music, (int) SR);
            if (music44 != music) {
                LOG.info("Resampling music: " + music.sampleRate + " Hz -> " + (int) SR + " Hz (linear interpolation)");
            }
            if (Math.abs(musicGainDb) > 1e-6) {
                float g = (float) Math.pow(10.0, musicGainDb / 20.0);
                for (float[] c : music44.channels) {
                    for (int i = 0; i < c.length; i++) {
                        c[i] *= g;
                    }
                }
                LOG.info(String.format("Music gain: %.1f dB (x%.3f) - подавление интермодуляции",
                        musicGainDb, g));
            }

            byte[] payload = data;
            if (mode.chirp) {
                payload = RsCodec.encode(data);
                LOG.info(String.format("FEC RS(%d,%d): %d -> %d bytes (+%.1f%%), "
                                + "corrects up to %d byte errors / %d erasures per block",
                        RsCodec.N, RsCodec.K, data.length, payload.length,
                        (payload.length - (double) data.length) * 100.0 / Math.max(1, data.length),
                        RsCodec.T, RsCodec.PARITY));
            }
            long crc1 = FrameCodec.crc32(data);
            long crc2 = mode.chirp ? FrameCodec.crc32c(data) : 0;
            int[] symbols = (mode == ModConfig.MODE_US)
                    ? new int[0]
                    : FrameCodec.buildSymbols(payload, crc1, crc2, mode, seed);
            if (mode.chirp) {
                LOG.info(String.format("CRC: #1 0x%08X (CRC32), #2 0x%08X (CRC-32C)",
                        crc1 & 0xFFFFFFFFL, crc2 & 0xFFFFFFFFL));
                if (seed != 0L) {
                    LOG.info(String.format("Stealth: seed=%d (jitter, random amplitude "
                                    + "0.7..1.0, random chirp curvature, length field XORed)", seed));
                }
            }
            ChirpMask mask = null;
            if (mode.chirp && maskK > 0.0) {
                float[] fskLen = Stealth.modulate(symbols, 1.0, mode, seed);
                float[] mono = monoMix(music44);
                mask = new MusicMask(mono, fskLen.length, maskK);
                LOG.info(String.format(
                        "Mask: K=%.2f (%.0f dB under local music; floor = absolute "
                                + "hearing threshold, -3 dB safety)",
                        maskK, 20.0 * Math.log10(maskK)));
                LOG.info("Mask: TX jitter OFF (short-symbol orthogonality); receiver: --seed "
                        + seed + " --mask");
            }
            float[] fsk;
            if (mode == ModConfig.MODE_US) {
                double usAmp = Math.pow(10.0, usAmpDb / 20.0);
                fsk = ru.vtb.streaming.player.codec.OfmModulator.modulate(payload, crc1, crc2, usAmp, usQam, usSubc, usInterleave, data);
                int bitsSubc = ru.vtb.streaming.player.codec.OfmModulator.bitsPerSubc(usQam);
                int bitsSym = usSubc * bitsSubc;
                double rawBps = bitsSym * (double) ru.vtb.streaming.player.codec.OfmModulator.SR
                        / ru.vtb.streaming.player.codec.OfmModulator.SYM_LEN;
                LOG.info(String.format(
                        "Mode: us (ultrasonic OFDM, 16.0-21.3 kHz, %d data subcarriers, "
                                + "%s, %.0f bit/s raw, level %.0f dBFS)",
                        usSubc, usQam == 2 ? "QPSK" : "16-QAM", rawBps, usAmpDb));
            } else {
                fsk = mode.chirp
                        ? Stealth.modulate(symbols, 1.0, mode, seed, mask)
                        : FskModulator.modulate(symbols, 1.0, mode);
            }
            int leadS = (int) Math.round(lead * SR);
            int tailS = (int) Math.round(tail * SR);
            int outLen = Math.max(music44.frameCount(), leadS + fsk.length + tailS);
            if (mode == ModConfig.MODE_US) {
                int ofmSyms = fsk.length / ru.vtb.streaming.player.codec.OfmModulator.SYM_LEN;
                int bitsSym = usSubc
                        * ru.vtb.streaming.player.codec.OfmModulator.bitsPerSubc(usQam);
                LOG.info(String.format("Frame: %d OFDM symbols = %d bits = %s; lead %s, tail %s",
                        ofmSyms, ofmSyms * bitsSym,
                        TimeFmt.seconds(fsk.length / SR), lead, tail));
            } else if (mode.chirp) {
                LOG.info(String.format("Mode: %s (chirp %.1f..%.1f kHz, %d samples/symbol, %.0f bit/s)",
                        mode.name, mode.freqs[0] / 1000.0, mode.freqs[mode.freqs.length - 1] / 1000.0,
                        mode.samplesPerSymbol, mode.bitRate));
                LOG.info(String.format("Frame: %d symbols = %d bits = %s; lead %s, tail %s, alpha %.4f",
                        symbols.length, mode.frameBits(payload.length),
                        TimeFmt.seconds(fsk.length / SR), lead, tail, alpha));
            } else {
                LOG.info(String.format("Mode: %s (FSK %s, %d bits/symbol, %.0f bit/s)",
                        mode.name, freqList(mode), mode.bitsPerSymbol, mode.bitRate));
                LOG.info(String.format("Frame: %d symbols = %d bits = %s; lead %s, tail %s, alpha %.4f",
                        symbols.length, mode.frameBits(payload.length),
                        TimeFmt.seconds(fsk.length / SR), lead, tail, alpha));
            }
            if (outLen > music44.frameCount()) {
                LOG.warning("Music is shorter than the frame - padding the signal tail with silence");
            }

            boolean useMaskedMix = (mask != null) || (mode == ModConfig.MODE_US);
            float[][] mixed = useMaskedMix
                    ? mixMasked(music44, fsk, leadS, outLen)
                    : mix(music44, fsk, leadS, alpha, outLen);
            double peak = 0.0;
            for (float[] c : mixed) {
                for (float v : c) {
                    double av = Math.abs(v);
                    if (av > peak) {
                        peak = av;
                    }
                }
            }
            if (peak > PEAK_LIMIT) {
                float scale = (float) (PEAK_LIMIT / peak);
                for (float[] c : mixed) {
                    for (int i = 0; i < c.length; i++) {
                        c[i] *= scale;
                    }
                }
                LOG.info(String.format("Normalizing: peak %.4f > %.2f, scale %.4f (clipping avoided)",
                        peak, PEAK_LIMIT, scale));
            } else {
                LOG.info(String.format("No normalization needed (peak %.4f)", peak));
            }

            int code = 0;
            Path outPath = (outArg == null) ? null : Path.of(outArg);
            if (outPath != null) {
                WavFile.write(outPath, (int) SR, mixed);
                LOG.info("Saved: " + outPath + " (44100 Hz, 16-bit, " + mixed.length + " ch)");
            }
            if (play) {
                int playFrames = leadS + fsk.length + tailS + (int) Math.round(PLAY_MARGIN_S * SR);
                playFrames = Math.min(playFrames, mixed[0].length);
                LOG.info(String.format("Playback: %s (lead %s + frame %s + tail %s + margin %.0f s)",
                        TimeFmt.seconds(playFrames / (double) SR), lead,
                        fsk.length / (double) SR, tail, PLAY_MARGIN_S));
                int pc = playLineOut(mixed, device, playFrames);
                if (pc != 0 && outPath == null) {
                    code = 1;
                }
            }
            return code;

        } catch (Args.ArgsException e) {
            LOG.severe(e.getMessage());
            return 1;
        } catch (IOException e) {
            LOG.severe("I/O error: " + e.getMessage());
            return 1;
        }
    }

    private static String freqList(ModConfig.Mode mode) {
        if (mode.freqs.length > 4) {
            return String.format(Locale.ROOT, "%.1f…%.1f kHz (%d тонов, шаг 100 Гц)",
                    mode.freqs[0] / 1000.0, mode.freqs[mode.freqs.length - 1] / 1000.0,
                    mode.freqs.length);
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < mode.freqs.length; i++) {
            if (i > 0) {
                sb.append('/');
            }
            sb.append(String.format(Locale.ROOT, "%.1f", mode.freqs[i] / 1000.0)).append(" kHz");
        }
        return sb.toString();
    }

    private static Mixer resolveMixer(String device, DataLine.Info info) {
        if (device == null || device.isBlank()) {
            return AudioSystem.isLineSupported(info) ? AudioSystem.getMixer(null) : null;
        }
        String needle = device.toLowerCase(Locale.ROOT);
        for (Mixer.Info mi : AudioSystem.getMixerInfo()) {
            if (mi.getName().toLowerCase(Locale.ROOT).contains(needle)) {
                Mixer m = AudioSystem.getMixer(mi);
                if (m != null && m.isLineSupported(info)) {
                    return m;
                }
            }
        }
        return null;
    }

    private static float[][] mixMasked(WavData music, float[] fsk, int lead, int outLen) {
        int ch = music.channelCount();
        float[][] out = new float[ch][outLen];
        for (int c = 0; c < ch; c++) {
            float[] m = music.channels[c];
            float[] o = out[c];
            int n = Math.min(m.length, outLen);
            System.arraycopy(m, 0, o, 0, n);
            int end = Math.min(lead + fsk.length, outLen);
            for (int i = lead; i < end; i++) {
                o[i] += fsk[i - lead];
            }
        }
        return out;
    }

    private static float[] monoMix(WavData music) {
        int ch = music.channelCount();
        int len = music.frameCount();
        float[] m = new float[len];
        for (int c = 0; c < ch; c++) {
            float[] cc = music.channels[c];
            for (int i = 0; i < len; i++) {
                m[i] += cc[i] / ch;
            }
        }
        return m;
    }

    private static float[][] mix(WavData music, float[] fsk, int lead, double alpha, int outLen) {
        int ch = music.channelCount();
        float[][] out = new float[ch][outLen];
        float kMusic = (float) (1.0 - alpha);
        for (int c = 0; c < ch; c++) {
            float[] m = music.channels[c];
            float[] o = out[c];
            int n = Math.min(m.length, outLen);
            for (int i = 0; i < n; i++) {
                o[i] = m[i] * kMusic;
            }
        }
        for (int c = 0; c < ch; c++) {
            float[] o = out[c];
            int end = Math.min(lead + fsk.length, outLen);
            for (int i = lead; i < end; i++) {
                o[i] += (float) (alpha * fsk[i - lead]);
            }
        }
        return out;
    }

    private int playLineOut(float[][] mixed, String device, int maxFrames) {
        int ch = mixed.length;
        int total = Math.min(mixed[0].length, maxFrames);
        AudioFormat fmt = new AudioFormat((float) SR, 16, ch, true, false);
        DataLine.Info info = new DataLine.Info(SourceDataLine.class, fmt);
        Mixer mixer = resolveMixer(device, info);
        if (mixer == null) {
            LOG.severe(device == null || device.isBlank()
                    ? "No line-out audio device available for format " + fmt
                    : "Playback not available on device \"" + device + "\"");
            return 1;
        }
        try (SourceDataLine line = (SourceDataLine) mixer.getLine(info)) {
            line.open(fmt);
            long t0 = System.nanoTime();
            line.start();
            LOG.info("Line-out: " + fmt + " (" + TimeFmt.seconds(total / (double) SR) + ")");
            final int chunkFrames = 4800;
            byte[] buf = new byte[chunkFrames * ch * 2];
            long worstWriteMs = 0;
            int worstWritePos = -1;
            for (int pos = 0; pos < total; pos += chunkFrames) {
                int frames = Math.min(chunkFrames, total - pos);
                int off = 0;
                for (int i = 0; i < frames; i++) {
                    for (int c = 0; c < ch; c++) {
                        float v = mixed[c][pos + i];
                        if (v > 1.0f) {
                            v = 1.0f;
                        } else if (v < -1.0f) {
                            v = -1.0f;
                        }
                        short s = (short) Math.round(v * 32767.0f);
                        buf[off++] = (byte) (s & 0xFF);
                        buf[off++] = (byte) ((s >>> 8) & 0xFF);
                    }
                }
                long w0 = System.nanoTime();
                line.write(buf, 0, off);
                long wms = (System.nanoTime() - w0) / 1_000_000;
                if (wms > worstWriteMs) {
                    worstWriteMs = wms;
                    worstWritePos = pos;
                    if (wms >= 15) {
                        LOG.warning(String.format(
                                "SLOW write: %d ms at sample %d (t=%s) — possible engine underrun",
                                wms, pos, TimeFmt.seconds(pos / (double) SR)));
                    }
                }
            }
            line.drain();
            double measured = (System.nanoTime() - t0) / 1e9;
            double expected = total / (double) SR;
            LOG.info(String.format("Playback finished: measured %.3f s, expected %.3f s (delta %+1.0f ms), worst write %d ms @ %d",
                    measured, expected, (measured - expected) * 1000, worstWriteMs, worstWritePos));
            return 0;
        } catch (LineUnavailableException e) {
            LOG.severe("Failed to open line-out: " + e.getMessage());
            return 1;
        }
    }
}
