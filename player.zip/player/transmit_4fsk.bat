@echo off
setlocal
cd /d C:\tools\_projects\_my\player

taskkill /F /IM java.exe >nul 2>&1
taskkill /F /IM Microsoft.Media.Player.exe >nul 2>&1

chcp 65001 >nul
java -Dstdout.encoding=UTF-8 -Dstderr.encoding=UTF-8 -jar target\player.jar transmit --play --music cozy.wav --data test_data.bin --mode 4fsk --device Realtek --alpha 0.2 --lead 3 --tail 1

echo.
echo Transmission finished.
pause
