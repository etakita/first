@echo off
setlocal

taskkill /F /IM java.exe >nul 2>&1
taskkill /F /IM Microsoft.Media.Player.exe >nul 2>&1

chcp 65001 >nul
java -Xmx4g -Dstdout.encoding=UTF-8 -Dstderr.encoding=UTF-8 -jar target\player.jar transmit --play --music cozy10.wav --data src.zip --device Realtek --mode us --us-qam 2 --us-subc 18 --us-amp -34 --music-gain -6

echo.
echo Transmission finished.
pause
