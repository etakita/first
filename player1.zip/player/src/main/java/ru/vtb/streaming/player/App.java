package ru.vtb.streaming.player;

import java.util.Locale;
import java.util.logging.Formatter;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;

public final class App {

    private App() {
    }

    public static void main(String[] args) {
        Locale.setDefault(Locale.ROOT); // точки в числах в логах, независимо от локали ОС
        configureLogging();
        int code;
        if (args.length == 0 || args[0].equals("help") || args[0].equals("-h") || args[0].equals("--help")) {
            usage();
            code = args.length == 0 ? 1 : 0;
        } else if (args[0].equals("transmit")) {
            code = new ru.vtb.streaming.player.transmit.TransmitCommand()
                    .run(java.util.Arrays.copyOfRange(args, 1, args.length));
        } else {
            System.err.println("Unknown command: " + args[0]);
            usage();
            code = 1;
        }
        System.exit(code);
    }

    /** Простое консольное логирование: [чч:мм:сс] УРОВЕНЬ сообщение. */
    private static void configureLogging() {
        Logger root = Logger.getLogger("");
        root.setLevel(Level.INFO);
        for (Handler h : root.getHandlers()) {
            h.setLevel(Level.INFO);
            try {
                h.setEncoding("UTF-8");
            } catch (java.io.UnsupportedEncodingException ignored) {
                // UTF-8 всегда поддерживается, но метод объявляет checked-исключение
            }
            h.setFormatter(new Formatter() {
                @Override
                public String format(LogRecord r) {
                    return String.format("[%1$tH:%1$tM:%1$tS] %2$-7s %3$s%n",
                            r.getMillis(), r.getLevel().getName(), r.getMessage());
                }
            });
        }
    }

    private static void usage() {
        System.out.println("""
                Covert data transmission over an audio cable (ultrasonic CPFSK) — PLAYER (transmitter)

                Channel modes (--mode):
                  2fsk   - 2-FSK 17.5/18.5 kHz, 1 bit/symbol, 100 bit/s (default)
                  4fsk   - 4-FSK 17.5/18.0/18.5/19.0 kHz, 2 bits/symbol, 200 bit/s (twice as fast)
                  16fsk  - 16-FSK 17.5...19.0 kHz (100 Hz step), 4 bits/symbol, 400 bit/s
                  32fsk  - 32-FSK 17.45...19.0 kHz (50 Hz step), 5 bits/symbol, 500 bit/s
                  64fsk  - 64-FSK 17.5...19.075 kHz (25 Hz step), 6 bits/symbol, 600 bit/s

                Usage:
                  java -jar player.jar transmit --music <music.wav> --data <secret.bin> \\
                       --output <mixed.wav> [--mode 2fsk|4fsk|16fsk|32fsk|64fsk] [--alpha 0.05] \\
                       [--lead 0.5] [--tail 0.5] [--play] [--device <name>]

                transmit:
                  --music   music WAV (PCM 16-bit, 48000 Hz, mono/stereo)
                  --data    file with the data to transmit (arbitrary binary)
                  --output  output WAV (44100 Hz, 16-bit)
                  --mode    channel mode: 2fsk (100 bit/s), 4fsk (200 bit/s), 16fsk (400 bit/s),
                            32fsk (500 bit/s) or 64fsk (600 bit/s); default 2fsk
                  --alpha   mixing coefficient (default 0.05)
                  --lead    data-free lead-in before the frame, s (default 0.5)
                  --tail    tail after the frame, s (default 0.5)
                  --play    output the mixed signal to line-out (can be combined with --output)
                  --device  audio device name (substring) for --play (e.g. Realtek); default - system device
                         (playback time for --play is computed automatically: lead + frame + tail + margin)
                """);
    }
}
