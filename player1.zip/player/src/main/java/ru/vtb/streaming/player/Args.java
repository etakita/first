package ru.vtb.streaming.player;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

public final class Args {

    public static final class ArgsException extends RuntimeException {
        public ArgsException(String message) {
            super(message);
        }
    }

    private final Map<String, String> values = new LinkedHashMap<>();
    private final Set<String> flags = new LinkedHashSet<>();

    public Args(String[] tokens) {
        for (int i = 0; i < tokens.length; i++) {
            String t = tokens[i];
            if (!t.startsWith("--") || t.length() < 3) {
                throw new ArgsException("Unknown argument: " + t + " (expected --option)");
            }
            String name = t.substring(2);
            if (i + 1 < tokens.length && !tokens[i + 1].startsWith("--")) {
                values.put(name, tokens[i + 1]);
                i++;
            } else {
                flags.add(name);
            }
        }
    }

    public String req(String name) {
        String v = values.get(name);
        if (v == null) {
            throw new ArgsException("Required option --" + name + " is missing");
        }
        return v;
    }

    public String str(String name, String def) {
        if (flags.contains(name)) {
            throw new ArgsException("Option --" + name + " requires a value");
        }
        return values.getOrDefault(name, def);
    }

    public double num(String name, double def) {
        String v = values.get(name);
        if (v == null) {
            if (flags.contains(name)) {
                throw new ArgsException("Option --" + name + " requires a value");
            }
            return def;
        }
        try {
            return Double.parseDouble(v);
        } catch (NumberFormatException e) {
            throw new ArgsException("Option --" + name + ": expected a number, got: " + v);
        }
    }

    public boolean flag(String name) {
        return flags.contains(name);
    }

    public boolean bool(String name, boolean def) {
        if (flags.contains(name)) {
            return true;
        }
        String v = values.get(name);
        if (v == null) {
            return def;
        }
        return v.equals("1") || v.equalsIgnoreCase("on") || v.equalsIgnoreCase("true") || v.equalsIgnoreCase("yes");
    }

    public boolean has(String name) {
        return values.containsKey(name) || flags.contains(name);
    }
}
