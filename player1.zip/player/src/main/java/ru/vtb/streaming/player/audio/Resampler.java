package ru.vtb.streaming.player.audio;

public final class Resampler {

    private Resampler() {
    }

    public static WavData resample(WavData in, int targetRate) {
        if (in.sampleRate == targetRate) {
            return in;
        }
        double ratio = in.sampleRate / (double) targetRate; // src -> dst
        int frames = (int) Math.round(in.frameCount() / ratio);
        float[][] out = new float[in.channelCount()][frames];
        for (int c = 0; c < in.channelCount(); c++) {
            float[] s = in.channels[c];
            float[] d = out[c];
            for (int i = 0; i < frames; i++) {
                double srcPos = i * ratio;
                int i0 = (int) srcPos;
                int i1 = Math.min(i0 + 1, s.length - 1);
                double frac = srcPos - i0;
                d[i] = (float) (s[i0] * (1.0 - frac) + s[i1] * frac);
            }
        }
        return new WavData(targetRate, out);
    }
}
