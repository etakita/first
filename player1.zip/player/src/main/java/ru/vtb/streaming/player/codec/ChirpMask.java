package ru.vtb.streaming.player.codec;

@FunctionalInterface
public interface ChirpMask {
    double scale(int framePos, double freq);
}
