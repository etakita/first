package ru.vtb.streaming.player.codec;

public final class CssModulator {

    private CssModulator() {
    }

    public static float[] modulate(int[] bits, double amplitude, ModConfig.Mode m) {
        return modulate(bits, amplitude, m, null);
    }

    public static float[] modulate(int[] bits, double amplitude, ModConfig.Mode m, ChirpMask mask) {
        int n = m.samplesPerSymbol;
        double f0 = m.freqs[0];
        double f1 = m.freqs[1];
        double sweep = f1 - f0;
        double sr = ModConfig.SAMPLE_RATE;
        double twoPi = 2.0 * Math.PI;
        float[] out = new float[bits.length * n];
        double phase = 0.0;
        int i = 0;
        for (int bit : bits) {
            for (int k = 0; k < n; k++) {
                double f = (bit == 0)
                        ? f0 + sweep * k / n
                        : f1 - sweep * k / n;
                double amp = amplitude * (mask == null ? 1.0 : mask.scale(i, f));
                out[i++] = (float) (amp * Math.sin(phase));
                phase += twoPi * f / sr;
                if (phase >= 8 * twoPi) {
                    phase -= 8 * twoPi;
                }
            }
        }
        return out;
    }
}
