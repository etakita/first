package ru.vtb.streaming.player.codec;

import java.util.zip.CRC32;

public final class FrameCodec {

    private FrameCodec() {
    }

    /** CRC32 полезной нагрузки (32 бита). */
    public static long crc32(byte[] data) {
        CRC32 crc = new CRC32();
        crc.update(data);
        return crc.getValue();
    }

    public static int[] buildBits(byte[] data) {
        return buildSymbols(data, ModConfig.MODE_2FSK);
    }

    public static int[] buildSymbols(byte[] data, ModConfig.Mode mode) {
        int bps = mode.bitsPerSymbol;
        int total = mode.frameSymbols(data.length);
        int[] syms = new int[total];
        // Преамбула (16 символов, задана режимом)
        System.arraycopy(mode.preamble, 0, syms, 0, ModConfig.PREAMBLE_SYMBOLS);
        int pos = ModConfig.PREAMBLE_SYMBOLS;
        // Длина данных в байтах, 32 бита big-endian
        pos = writeField(syms, pos, data.length & 0xFFFFFFFFL, ModConfig.LENGTH_BITS, bps);

        int dataBits = data.length * 8;
        int fieldBits = ModConfig.Mode.fieldBits(dataBits, bps);
        int acc = 0, n = 0;
        for (int i = 0; i < fieldBits; i++) {
            int bit = (i < dataBits) ? ((data[i >>> 3] >>> (7 - (i & 7))) & 1) : 0;
            acc = (acc << 1) | bit;
            if (++n == bps) {
                syms[pos++] = acc;
                acc = 0;
                n = 0;
            }
        }
        // CRC32, 32 бита big-endian
        pos = writeField(syms, pos, crc32(data), ModConfig.CRC_BITS, bps);
        if (pos != total) {
            throw new IllegalStateException("Internal frame packing error: " + pos + " != " + total);
        }
        return syms;
    }

    private static int writeField(int[] syms, int pos, long value, int count, int bps) {
        int acc = 0, n = 0;
        for (int i = count - 1; i >= 0; i--) {
            acc = (acc << 1) | (int) ((value >>> i) & 1L);
            if (++n == bps) {
                syms[pos++] = acc;
                acc = 0;
                n = 0;
            }
        }
        while (n != 0) {
            acc <<= 1; // нулевое дополнение до границы символа
            if (++n == bps) {
                syms[pos++] = acc;
                acc = 0;
                n = 0;
            }
        }
        return pos;
    }
}
