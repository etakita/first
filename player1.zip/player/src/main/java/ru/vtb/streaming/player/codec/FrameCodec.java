package ru.vtb.streaming.player.codec;

import java.util.zip.CRC32;

public final class FrameCodec {

    private FrameCodec() {
    }

    public static long crc32(byte[] data) {
        CRC32 crc = new CRC32();
        crc.update(data);
        return crc.getValue();
    }

    public static long crc32c(byte[] data) {
        long crc = 0xFFFFFFFFL;
        for (byte b : data) {
            crc ^= (b & 0xFFL);
            for (int i = 0; i < 8; i++) {
                crc = ((crc & 1L) != 0) ? ((crc >>> 1) ^ 0x82F63B78L) : (crc >>> 1);
            }
        }
        return (crc ^ 0xFFFFFFFFL) & 0xFFFFFFFFL;
    }

    public static int[] buildBits(byte[] data) {
        return buildSymbols(data, ModConfig.MODE_2FSK);
    }

    public static int[] buildSymbols(byte[] data, ModConfig.Mode mode) {
        return buildSymbols(data, crc32(data), mode);
    }

    public static int[] buildSymbols(byte[] data, long crc, ModConfig.Mode mode) {
        return buildSymbols(data, crc, 0, mode);
    }

    public static int[] buildSymbols(byte[] data, long crc, long crc2, ModConfig.Mode mode) {
        return buildSymbols(data, crc, crc2, mode, 0L);
    }

    public static int[] buildSymbols(byte[] data, long crc, long crc2, ModConfig.Mode mode, long seed) {
        int bps = mode.bitsPerSymbol;
        int total = mode.frameSymbols(data.length);
        int[] syms = new int[total];

        System.arraycopy(mode.preamble, 0, syms, 0, ModConfig.PREAMBLE_SYMBOLS);
        int pos = ModConfig.PREAMBLE_SYMBOLS;

        for (int r = 0; r < (mode.chirp ? ModConfig.LENGTH_REP : 1); r++) {
            pos = writeField(syms, pos, data.length & 0xFFFFFFFFL, ModConfig.LENGTH_BITS, bps);
        }

        if (seed != 0L && mode.chirp) {
            long[] st = {Stealth.lengthSeed(seed)};
            for (int r = 0; r < ModConfig.LENGTH_REP; r++) {
                for (int i = 0; i < ModConfig.LENGTH_BITS; i++) {
                    syms[ModConfig.PREAMBLE_SYMBOLS + r * ModConfig.LENGTH_BITS + i]
                            ^= (int) ((Stealth.next(st) >>> 61) & 1L);
                }
            }
        }

        int dataBits = data.length * 8;
        int fieldBits = ModConfig.Mode.fieldBits(dataBits, bps);
        int acc = 0, n = 0;
        for (int i = 0; i < fieldBits; i++) {
            int bit = (i < dataBits) ? ((data[i >>> 3] >>> (7 - (i & 7))) & 1) : 0;
            acc = (acc << 1) | bit;
            if (++n == bps) {
                syms[pos++] = acc;
                acc = 0;
                n = 0;
            }
        }

        pos = writeField(syms, pos, crc, ModConfig.CRC_BITS, bps);
        if (mode.chirp) {
            pos = writeField(syms, pos, crc2, ModConfig.CRC_BITS, bps);
            pos = writeField(syms, pos, crc, ModConfig.CRC_BITS, bps);
            pos = writeField(syms, pos, crc2, ModConfig.CRC_BITS, bps);
        }
        if (pos != total) {
            throw new IllegalStateException("Internal frame packing error: " + pos + " != " + total);
        }
        return syms;
    }

    public static int[] buildFrameBits(byte[] data, long crc1, long crc2) {
        return buildFrameBits(data, crc1, crc2, false);
    }

    public static int[] buildFrameBits(byte[] data, long crc1, long crc2, boolean interleaved) {
        int bps = 1;
        int total = ModConfig.LENGTH_BITS * ModConfig.LENGTH_REP
                + data.length * 8 + 4 * ModConfig.CRC_BITS;
        int[] bits = new int[total];
        int pos = 0;
        for (int r = 0; r < ModConfig.LENGTH_REP; r++) {
            pos = writeField(bits, pos, data.length & 0xFFFFFFFFL, ModConfig.LENGTH_BITS, bps);
        }
        int dataBits = data.length * 8;
        int[] region = new int[dataBits + 4 * ModConfig.CRC_BITS];
        int rp = 0;
        for (int i = 0; i < dataBits; i++) {
            region[rp++] = (data[i >>> 3] >>> (7 - (i & 7))) & 1;
        }
        rp = writeBits(region, rp, crc1, ModConfig.CRC_BITS);
        rp = writeBits(region, rp, crc2, ModConfig.CRC_BITS);
        rp = writeBits(region, rp, crc1, ModConfig.CRC_BITS);
        rp = writeBits(region, rp, crc2, ModConfig.CRC_BITS);
        if (interleaved) {
            int s = interleaveStride(region.length);
            int[] out = new int[region.length];
            for (int i = 0; i < region.length; i++) {
                out[(i * s) % region.length] = region[i];
            }
            region = out;
        }
        System.arraycopy(region, 0, bits, pos, region.length);
        if (pos + region.length != total) {
            throw new IllegalStateException("frame bits packing error");
        }
        return bits;
    }

    public static int interleaveStride(int m) {
        int[] primes = {127, 131, 137, 139, 149, 151, 157, 163, 167, 173, 179, 181, 191, 193, 197, 199, 211, 223, 227, 229};
        for (int p : primes) {
            if (p < m && gcd(p, m) == 1) {
                return p;
            }
        }
        throw new IllegalStateException("no interleave stride for M=" + m);
    }

    private static int gcd(int a, int b) {
        while (b != 0) {
            int t = a % b;
            a = b;
            b = t;
        }
        return a;
    }

    private static int writeBits(int[] out, int pos, long value, int count) {
        for (int i = count - 1; i >= 0; i--) {
            out[pos++] = (int) ((value >>> i) & 1L);
        }
        return pos;
    }

    private static int writeField(int[] syms, int pos, long value, int count, int bps) {
        int acc = 0, n = 0;
        for (int i = count - 1; i >= 0; i--) {
            acc = (acc << 1) | (int) ((value >>> i) & 1L);
            if (++n == bps) {
                syms[pos++] = acc;
                acc = 0;
                n = 0;
            }
        }
        while (n != 0) {
            acc <<= 1;
            if (++n == bps) {
                syms[pos++] = acc;
                acc = 0;
                n = 0;
            }
        }
        return pos;
    }
}
