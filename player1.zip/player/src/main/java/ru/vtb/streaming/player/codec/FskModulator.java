package ru.vtb.streaming.player.codec;

public final class FskModulator {

    private FskModulator() {
    }

    public static float[] modulate(int[] bits, double amplitude) {
        return modulate(bits, amplitude, 0.0, ModConfig.MODE_2FSK);
    }

    public static float[] modulate(int[] symbols, double amplitude, ModConfig.Mode mode) {
        return modulate(symbols, amplitude, 0.0, mode);
    }

    public static float[] modulate(int[] symbols, double amplitude, double initialPhase, ModConfig.Mode mode) {
        double sr = ModConfig.SAMPLE_RATE;
        int spp = ModConfig.SAMPLES_PER_SYMBOL;
        double twoPi = 2.0 * Math.PI;
        float[] out = new float[symbols.length * spp];
        double phase = initialPhase;
        int i = 0;
        for (int s : symbols) {
            double f = mode.freqs[s];
            double dPhase = twoPi * f / sr;
            for (int n = 0; n < spp; n++) {
                out[i++] = (float) (amplitude * Math.sin(phase));
                phase += dPhase;
                if (phase >= twoPi) {
                    phase -= twoPi;
                }
            }
        }
        return out;
    }
}
