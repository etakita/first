package ru.vtb.streaming.player.codec;

public final class ModConfig {

    private ModConfig() {
    }

    public static final double SAMPLE_RATE = 44100.0;

    public static final int SAMPLES_PER_SYMBOL = 441;

    public static final int SAMPLES_PER_BIT = SAMPLES_PER_SYMBOL;

    public static final int PREAMBLE_SYMBOLS = 16;

    public static final int PREAMBLE_BITS = PREAMBLE_SYMBOLS;

    public static final int LENGTH_BITS = 32;

    public static final int LENGTH_REP = 12;

    public static final int CRC_BITS = 32;

    public static final int HEADER_BITS = PREAMBLE_SYMBOLS + LENGTH_BITS;

    public static final double DETECT_MIN_POWER = 5.0e-6;

    public static final double DETECT_MIN_CONTRAST = 6.0;

    public static final double FREQ_0 = 17500.0;
    public static final double FREQ_1 = 18500.0;

    public static final class Mode {

        public final String name;

        public final int bitsPerSymbol;

        public final double[] freqs;

        public final double[] bins;

        public final boolean dense;

        public final int samplesPerSymbol;

        public final boolean chirp;

        public final int[] preamble;

        public final double bitRate;

        Mode(String name, int bitsPerSymbol, double[] freqs, int[] preamble) {
            this(name, bitsPerSymbol, freqs, preamble, SAMPLES_PER_SYMBOL, false);
        }

        Mode(String name, int bitsPerSymbol, double[] freqs, int[] preamble,
             int samplesPerSymbol, boolean chirp) {
            this.name = name;
            this.bitsPerSymbol = bitsPerSymbol;
            this.freqs = freqs;
            this.preamble = preamble;
            this.samplesPerSymbol = samplesPerSymbol;
            this.chirp = chirp;
            this.bins = new double[freqs.length];
            boolean dense = false;
            for (int i = 0; i < freqs.length; i++) {
                this.bins[i] = freqs[i] / (SAMPLE_RATE / SAMPLES_PER_SYMBOL);
                if (Math.abs(this.bins[i] - Math.rint(this.bins[i])) > 1e-9) {
                    dense = true;
                }
            }
            this.dense = dense;
            this.bitRate = (SAMPLE_RATE / samplesPerSymbol) * bitsPerSymbol;
        }

        public static int fieldBits(int bits, int bps) {
            return ((bits + bps - 1) / bps) * bps;
        }

        public int frameBits(int dataBytes) {
            int crcBits = chirp ? 4 * CRC_BITS : CRC_BITS;
            return headerBits() + fieldBits(dataBytes * 8, bitsPerSymbol)
                    + fieldBits(crcBits, bitsPerSymbol);
        }

        public int frameSymbols(int dataBytes) {
            return frameBits(dataBytes) / bitsPerSymbol;
        }

        public int frameSamples(int dataBytes) {
            return frameSymbols(dataBytes) * samplesPerSymbol;
        }

        public int headerBits() {
            int reps = chirp ? LENGTH_REP : 1;
            return PREAMBLE_SYMBOLS * bitsPerSymbol + fieldBits(LENGTH_BITS * reps, bitsPerSymbol);
        }

        public int group(int symbol) {
            return symbol < freqs.length / 2 ? 0 : 1;
        }

        @Override
        public String toString() {
            return name;
        }
    }

    public static final Mode MODE_2FSK = new Mode(
            "2fsk", 1,
            new double[]{FREQ_0, FREQ_1},
            new int[]{1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0});

    public static final Mode MODE_4FSK = new Mode(
            "4fsk", 2,
            new double[]{17500.0, 18000.0, 18500.0, 19000.0},
            new int[]{1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2});

    public static final Mode MODE_16FSK = new Mode(
            "16fsk", 4,
            new double[]{17500.0, 17600.0, 17700.0, 17800.0, 17900.0, 18000.0,
                    18100.0, 18200.0, 18300.0, 18400.0, 18500.0, 18600.0,
                    18700.0, 18800.0, 18900.0, 19000.0},
            new int[]{2, 10, 2, 10, 2, 10, 2, 10, 2, 10, 2, 10, 2, 10, 2, 10});

    public static final Mode MODE_32FSK = new Mode(
            "32fsk", 5,
            denseFreqs(17450.0, 50.0, 32),
            alternating(0, 31));

    public static final Mode MODE_64FSK = new Mode(
            "64fsk", 6,
            denseFreqs(17500.0, 25.0, 64),
            alternating(0, 50));

    public static final Mode MODE_CSS = new Mode(
            "css", 1,
            new double[]{14700.0, 19600.0},
            new int[]{1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0},
            36, true);

    public static final Mode MODE_CSS2 = new Mode(
            "css2", 1,
            new double[]{12250.0, 19600.0},
            new int[]{1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0},
            24, true);

    public static final Mode MODE_CSS3 = new Mode(
            "css3", 1,
            new double[]{9800.0, 19600.0},
            new int[]{1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0},
            18, true);

    public static final Mode MODE_CSS4 = new Mode(
            "css4", 1,
            new double[]{4900.0, 19600.0},
            new int[]{1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0},
            12, true);

    public static final Mode MODE_CSS5 = new Mode(
            "css5", 1,
            new double[]{0.0, 19600.0},
            new int[]{1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0},
            9, true);

    public static final Mode MODE_US = new Mode(
            "us", 128,
            usSubcarrierFreqs(),
            new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            272, true);

    private static double[] usSubcarrierFreqs() {
        double[] f = new double[32];
        for (int i = 0; i < 32; i++) {
            f[i] = 16000.0 + i * 172.3;
        }
        return f;
    }

    public static final Mode[] ALL = {MODE_2FSK, MODE_4FSK, MODE_16FSK, MODE_32FSK, MODE_64FSK,
            MODE_CSS, MODE_CSS2, MODE_CSS3, MODE_CSS4, MODE_CSS5, MODE_US};

    private static double[] denseFreqs(double f0, double step, int n) {
        double[] f = new double[n];
        for (int i = 0; i < n; i++) {
            f[i] = f0 + i * step;
        }
        return f;
    }

    private static int[] alternating(int a, int b) {
        int[] p = new int[PREAMBLE_SYMBOLS];
        for (int i = 0; i < PREAMBLE_SYMBOLS; i++) {
            p[i] = (i % 2 == 0) ? a : b;
        }
        return p;
    }

    public static final double[] SCAN_FREQS = MODE_16FSK.freqs;

    public static Mode byName(String s) {
        if (s == null) {
            throw new IllegalArgumentException("Mode not set");
        }
        for (Mode m : ALL) {
            if (m.name.equalsIgnoreCase(s)) {
                return m;
            }
        }
        throw new IllegalArgumentException("Unknown mode: " + s
                + " (available: 2fsk, 4fsk, 16fsk, 32fsk, 64fsk, css, css2, css3, css4, css5, us)");
    }

    public static int frameBits(int dataBytes) {
        return MODE_2FSK.frameBits(dataBytes);
    }

    public static int frameSamples(int dataBytes) {
        return MODE_2FSK.frameSamples(dataBytes);
    }
}
