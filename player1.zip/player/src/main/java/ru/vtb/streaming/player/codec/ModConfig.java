package ru.vtb.streaming.player.codec;

public final class ModConfig {

    private ModConfig() {
    }

    /** Частота дискретизации скрытого канала, Гц. */
    public static final double SAMPLE_RATE = 44100.0;

    /** Длительность символа в сэмпелах: 44100 / 100 = 441 (10 мс). */
    public static final int SAMPLES_PER_SYMBOL = 441;

    /** Длительность бита в сэмпелах (режим 2fsk, символ = бит; совместимость). */
    public static final int SAMPLES_PER_BIT = SAMPLES_PER_SYMBOL;

    /** Преамбула: 16 символов (в 2fsk — 16 бит). */
    public static final int PREAMBLE_SYMBOLS = 16;

    /** Преамбула в битах (режим 2fsk; совместимость). */
    public static final int PREAMBLE_BITS = PREAMBLE_SYMBOLS;

    /** Поле длины данных в байтах, бит. */
    public static final int LENGTH_BITS = 32;

    /** Контрольная сумма CRC32, бит. */
    public static final int CRC_BITS = 32;

    /** Преамбула + заголовок, бит (режим 2fsk; совместимость). */
    public static final int HEADER_BITS = PREAMBLE_SYMBOLS + LENGTH_BITS;

    /** Минимальная абсолютная энергия символа для признания его «видимым» (нормированная |X|^2/N^2). */
    public static final double DETECT_MIN_POWER = 5.0e-6;

    /** Минимальный контраст max(P)/secondMax(P) для признания символа уверенным (~7.8 дБ). */
    public static final double DETECT_MIN_CONTRAST = 6.0;

    /** Частоты логического 0/1 режима 2fsk (совместимость). */
    public static final double FREQ_0 = 17500.0;
    public static final double FREQ_1 = 18500.0;

    /**
     * Настройка режима: алфавит FSK, преамбула, биты на символ.
     */
    public static final class Mode {
        /** Имя режима: "2fsk" или "4fsk". */
        public final String name;
        /** Число бит на символ (1 или 2). */
        public final int bitsPerSymbol;
        /** Частоты FSK по возрастанию, Гц. */
        public final double[] freqs;
        /** Частоты FSK в бинах (freqs / 100 Гц); для плотных режимов дробные. */
        public final double[] bins;
        /** Плотный алфавит: хотя бы один тон вне бинов 100 Гц (32fsk/64fsk). */
        public final boolean dense;
        /** Преамбула: 16 символов (значения — индексы в freqs). */
        public final int[] preamble;
        /** Пропускная способность, бит/с. */
        public final double bitRate;

        Mode(String name, int bitsPerSymbol, double[] freqs, int[] preamble) {
            this.name = name;
            this.bitsPerSymbol = bitsPerSymbol;
            this.freqs = freqs;
            this.preamble = preamble;
            this.bins = new double[freqs.length];
            boolean dense = false;
            for (int i = 0; i < freqs.length; i++) {
                this.bins[i] = freqs[i] / (SAMPLE_RATE / SAMPLES_PER_SYMBOL);
                if (Math.abs(this.bins[i] - Math.rint(this.bins[i])) > 1e-9) {
                    dense = true;
                }
            }
            this.dense = dense;
            this.bitRate = (SAMPLE_RATE / SAMPLES_PER_SYMBOL) * bitsPerSymbol;
        }

        /** Поле в битах, дополненное нулями до границы символа (кратное bps). */
        public static int fieldBits(int bits, int bps) {
            return ((bits + bps - 1) / bps) * bps;
        }

        /** Число бит кадра для заданного размера полезной нагрузки. */
        public int frameBits(int dataBytes) {
            return headerBits() + fieldBits(dataBytes * 8, bitsPerSymbol)
                    + fieldBits(CRC_BITS, bitsPerSymbol);
        }

        /** Число символов кадра для заданного размера полезной нагрузки. */
        public int frameSymbols(int dataBytes) {
            return frameBits(dataBytes) / bitsPerSymbol;
        }

        /** Число сэмпел кадра (без учёта lead/tail). */
        public int frameSamples(int dataBytes) {
            return frameSymbols(dataBytes) * SAMPLES_PER_SYMBOL;
        }

        /** Число бит заголовка (преамбула + поле длины, дополненное до символа). */
        public int headerBits() {
            return PREAMBLE_SYMBOLS * bitsPerSymbol + fieldBits(LENGTH_BITS, bitsPerSymbol);
        }

        /**
         * Группа символа для единого поиска преамбулы:
         * 0 — нижняя половина алфавита, 1 — верхняя.
         * Преамбулы обоих режимов чередуют группы, поэтому один и тот же
         * «цепочечный» скан находит оба режима.
         */
        public int group(int symbol) {
            return symbol < freqs.length / 2 ? 0 : 1;
        }

        @Override
        public String toString() {
            return name;
        }
    }

    public static final Mode MODE_2FSK = new Mode(
            "2fsk", 1,
            new double[]{FREQ_0, FREQ_1},
            new int[]{1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0});

    public static final Mode MODE_4FSK = new Mode(
            "4fsk", 2,
            new double[]{17500.0, 18000.0, 18500.0, 19000.0},
            new int[]{1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2});

    public static final Mode MODE_16FSK = new Mode(
            "16fsk", 4,
            new double[]{17500.0, 17600.0, 17700.0, 17800.0, 17900.0, 18000.0,
                    18100.0, 18200.0, 18300.0, 18400.0, 18500.0, 18600.0,
                    18700.0, 18800.0, 18900.0, 19000.0},
            new int[]{2, 10, 2, 10, 2, 10, 2, 10, 2, 10, 2, 10, 2, 10, 2, 10});

    public static final Mode MODE_32FSK = new Mode(
            "32fsk", 5,
            denseFreqs(17450.0, 50.0, 32),
            alternating(0, 31));

    public static final Mode MODE_64FSK = new Mode(
            "64fsk", 6,
            denseFreqs(17500.0, 25.0, 64),
            alternating(0, 50));

    /** Все режимы; порядок = приоритет при автоопределении. */
    public static final Mode[] ALL = {MODE_2FSK, MODE_4FSK, MODE_16FSK, MODE_32FSK, MODE_64FSK};

    /** Алфавит: n тонов f0 + i*step, Гц. */
    private static double[] denseFreqs(double f0, double step, int n) {
        double[] f = new double[n];
        for (int i = 0; i < n; i++) {
            f[i] = f0 + i * step;
        }
        return f;
    }

    /** Преамбула: 16 символов, чередование двух индексов. */
    private static int[] alternating(int a, int b) {
        int[] p = new int[PREAMBLE_SYMBOLS];
        for (int i = 0; i < PREAMBLE_SYMBOLS; i++) {
            p[i] = (i % 2 == 0) ? a : b;
        }
        return p;
    }

    /**
     * Единый алфавит грубого скана: частоты 16fsk (супермножество 2fsk и 4fsk).
     * Окно с тоном любого режима «видно» Гёрцелем хотя бы на одной из них.
     */
    public static final double[] SCAN_FREQS = MODE_16FSK.freqs;

    /** Режим по имени (без учёта регистра); бросает IllegalArgumentException. */
    public static Mode byName(String s) {
        if (s == null) {
            throw new IllegalArgumentException("Mode not set");
        }
        for (Mode m : ALL) {
            if (m.name.equalsIgnoreCase(s)) {
                return m;
            }
        }
        throw new IllegalArgumentException("Unknown mode: " + s + " (available: 2fsk, 4fsk, 16fsk, 32fsk, 64fsk)");
    }

    /**
     * Число бит кадра для заданного размера полезной нагрузки (режим 2fsk,
     * совместимость со старой сигнатурой).
     */
    public static int frameBits(int dataBytes) {
        return MODE_2FSK.frameBits(dataBytes);
    }

    /**
     * Число сэмпел кадра (режим 2fsk, совместимость со старой сигнатурой).
     */
    public static int frameSamples(int dataBytes) {
        return MODE_2FSK.frameSamples(dataBytes);
    }
}
