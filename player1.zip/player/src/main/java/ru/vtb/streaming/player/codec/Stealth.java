package ru.vtb.streaming.player.codec;

import java.util.Arrays;

public final class Stealth {
    private Stealth() {
    }

    public static long next(long[] st) {
        long z = (st[0] += 0x9E3779B97F4A7C15L);
        z = (z ^ (z >>> 30)) * 0xBF58476D1CE4E5B9L;
        z = (z ^ (z >>> 27)) * 0x94D049BB133111EBL;
        return z ^ (z >>> 31);
    }

    public static double uniform(long[] st) {
        return (next(st) >>> 11) * (1.0 / (1L << 53));
    }

    public static long lengthSeed(long seed) {
        return seed * 0x9E3779B97F4A7C15L + 0x51ED270BL;
    }

    public static int jitter(int n) {
        if (n < 12) {
            return 0;
        }
        if (n == 12) {
            return 2;
        }
        return Math.min(6, n / 2 - 4);
    }

    public static float[] modulate(int[] bits, double amplitude, ModConfig.Mode m, long seed) {
        return modulate(bits, amplitude, m, seed, null);
    }

    public static float[] modulate(int[] bits, double amplitude, ModConfig.Mode m, long seed, ChirpMask mask) {
        if (seed == 0L) {
            return CssModulator.modulate(bits, amplitude, m, mask);
        }
        int pre = ModConfig.PREAMBLE_SYMBOLS;
        int n = m.samplesPerSymbol;

        int J = (mask != null) ? 0 : jitter(n);
        double f0 = m.freqs[0];
        double f1 = m.freqs[1];
        double sweep = f1 - f0;
        double sr = ModConfig.SAMPLE_RATE;
        double twoPi = 2.0 * Math.PI;
        long[] st = {seed};
        float[] out = new float[bits.length * (n + J) + 2 * n];
        double phase = 0.0;
        int pos = 0;
        for (int k = 0; k < pre; k++) {
            for (int t = 0; t < n; t++) {
                double f = (bits[k] == 0) ? f0 + sweep * t / n : f1 - sweep * t / n;
                double amp = amplitude * (mask == null ? 1.0 : mask.scale(pos + t, f));
                out[pos + t] = (float) (amp * Math.sin(phase));
                phase += twoPi * f / sr;
                if (phase >= 8 * twoPi) {
                    phase -= 8 * twoPi;
                }
            }
            pos += n;
        }
        int end = 0;
        for (int k = pre; k < bits.length; k++) {
            double a = amplitude * (0.8 + 0.2 * uniform(st));
            double e1 = (2.0 * uniform(st) - 1.0) * 0.1;
            double e2 = (2.0 * uniform(st) - 1.0) * 0.1;
            int delta = (J == 0) ? 0 : (int) (uniform(st) * (2 * J + 1)) - J;
            for (int t = 0; t < n; t++) {
                double u = t / (double) n;
                double w = u + e1 * u * (1.0 - u) * Math.sin(twoPi * u)
                        + e2 * u * (1.0 - u) * (u - 0.5) * Math.cos(twoPi * u);
                double f = (bits[k] == 0) ? f0 + sweep * w : f1 - sweep * w;
                double amp = a * (mask == null ? 1.0 : mask.scale(pos + t, f));
                out[pos + t] += (float) (amp * Math.sin(phase));
                phase += twoPi * f / sr;
                if (phase >= 8 * twoPi) {
                    phase -= 8 * twoPi;
                }
            }
            end = Math.max(end, pos + n);
            pos += n + delta;
        }
        return Arrays.copyOf(out, end);
    }
}
