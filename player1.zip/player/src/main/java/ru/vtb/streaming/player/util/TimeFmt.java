package ru.vtb.streaming.player.util;

public final class TimeFmt {

    private TimeFmt() {
    }

    public static String seconds(double s) {
        if (s < 0) {
            s = 0;
        }
        long ms = (long) (s * 1000.0);
        long h = ms / 3_600_000;
        long m = (ms / 60_000) % 60;
        long sec = (ms / 1000) % 60;
        long mss = ms % 1000;
        if (h > 0) {
            return String.format("%d:%02d:%02d.%03d", h, m, sec, mss);
        }
        return String.format("%d:%02d.%03d", m, sec, mss);
    }
}
