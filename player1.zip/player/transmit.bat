@echo off
setlocal
cd /d C:\tools\_projects\_my\player

echo ============================================================
echo  PLAYER (Line out, Realtek)
echo  1 KB into cozy.wav, out to line-out jack
echo  frame: 82.2 s at 100 bit/s, starts at 3 s
echo  plays lead + frame + tail + 1 s margin (auto, ~87 s)
echo ============================================================
echo.

taskkill /F /IM java.exe >nul 2>&1
taskkill /F /IM Microsoft.Media.Player.exe >nul 2>&1

chcp 65001 >nul
java -Dstdout.encoding=UTF-8 -Dstderr.encoding=UTF-8 -jar target\player.jar transmit --play --music cozy.wav --data test_data.bin --device Realtek --alpha 0.2 --lead 3 --tail 1

echo.
echo Transmission finished.
pause
