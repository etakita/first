@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo  PLAYER us (Line out, Realtek) - Ultrasonic OFDM
echo  fastest mode that really works: QPSK, 18 data subcarriers
echo  band 16.19-18.94 kHz, ~4800 bit/s payload (1.31x css4)
echo  1 KB frame ~2.0 s; music cozy.wav at -6 dB, us at -38 dBFS
echo  inaudible: data band 22-26 dB SPL vs ISO 226 threshold 55-74 dB
echo.
echo  RX side: receiver\receive_us.bat - start it first, it waits
echo  for the frame (no timing coordination needed)
echo ============================================================
echo.

taskkill /F /IM java.exe >nul 2>&1
taskkill /F /IM Microsoft.Media.Player.exe >nul 2>&1

chcp 65001 >nul
java -Dstdout.encoding=UTF-8 -Dstderr.encoding=UTF-8 -jar target\player.jar transmit --play --music cozy.wav --data test_data.bin --device Realtek --mode us --us-qam 2 --us-subc 18 --us-amp -38 --music-gain -6

echo.
echo Transmission finished.
pause
